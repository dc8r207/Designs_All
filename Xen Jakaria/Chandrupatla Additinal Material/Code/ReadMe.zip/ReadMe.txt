INTRODUCTION TO FINITE ELEMENTS IN ENGINEERING
5 TH EDITION
Tirupathi R. Chandrupatla
Ashok D. Belegundu

Downloadable COMPUTER PROGRAMS and Data Files

Computer program source codes are provided on the following platforms.

Visual Basic Excel (VB Excel)
Javascript
Python
MATLAB
Ansi C
FORTRAN
EXAMPLES  (input Data files for Python, MATLAB, C, Fortran)
EXTRAS    (All Solved examples + DKT + Cuthill-McKee etc in Matlab)

Instructions

VB Excel programs can be run like a spread sheet using Excel.
   Pressing Alt+F11 shows the VB code. Users will be able to
   see how data from Sheet1 are read, processed and how
   results are presented on Sheet2.
   (To run a different problem edit data in Sheet1)

Javascript programs can be run using Google Chrome, Internet
   Explorer, Firefox, Safari, Microsoft Edge. To load the file
   right click on the file and use "open with" option.
   When the file is open "right click" and "view source" to 
   see the source code. See help pages fod debugging.
   In Google Chrome pressing F12 shows the source screen.
   (To run a different problem edit data in upper screen)

Python programs can be run using Spyder IDE program in ANACONDA.
   Anaconda/Spyder are open source programs which can be downloaded.
   (Place input data files from EXAMPLES in the directory)

MATLAB programs can be run using MATLAB from Mathsoft. MATLAB
   is a a widely available program in colleges and universities.
   (Place input data files from EXAMPLES in the directory)

Ansi C programs can be run using open source program such as
   CODEBLOCKS by choosing GNU Gcc compiler in the settings.
   Programs run in the DOS screen.
   Chapter 12 programs are not provided in Ansi C.
   (Place input data files from EXAMPLES in the directory)

FORTRAN programs can be run using open source program such as
   CODEBLOCKS by choosing GNU Fortran compiler option in 
   the settings. Programs run in the DOS screen. 
   Chapter 12 programs are not provided in FORTRAN.
   (Place input data files from EXAMPLES in the directory)

Note: All programs have been thoroughly checked and tested.
   It is user's responsibility to use the programs.