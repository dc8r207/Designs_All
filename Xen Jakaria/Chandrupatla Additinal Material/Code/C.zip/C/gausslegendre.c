    /*----   program gauss-legendre  -----*/
    /* Integration points and weights     */
    /* t.r.chandrupatla and a.d.belegundu */
    /*------------------------------------*/
    #include <stdio.h>
    #include <stdlib.h>
    #include <math.h>
    int main(){
      int n,i,j,n1;
      double PI = 3.14159265358979;
      double p1,p2,p3,x,w,dp;
      printf("Number of Integraion Points? ");
      scanf("%d", &n);
      p3 = 0;
      printf("IntegrationPoint +-x       WeightFactor\n");

      n1 = floor((n + 1) / 2);
      for (j = 1; j < n1+1; j++){
        x = cos(PI * (j - 1. / 4) / (n + 1. / 2));
        do {
           p1 = 0;
           p2 = 1;
           for (i = 1; i < n+1; i++){
              p3 = (2. - 1. / i) * x * p2 - (1. - 1. / i) * p1;
              p1 = p2;
              p2 = p3;
           }
           dp = n / (x*x - 1.) * (x * p2 - p1);
           x = x - p2 / dp;
        } while (fabs(p3) > 0.0000000001);
        w = 2 / (1 - x*x) / (dp*dp);
        printf("%16.8e %16.8e\n", x,w);
      }
      return (0);
}//Gauss Legendre
