function [] = Example_9_1_beam_deflection_plot()
clear all;close all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
x(1)= 5; x(2)= 8;
q =[-0.01 -0.1 0.14 -0.2]';
psi=[-1:.1:1];
le = abs(x(2)-x(1));
H1= .25*(1-psi).^2 .*(2+psi);
H2= .25*(1-psi).^2 .*(psi+1);
H3= .25*(1+psi).^2 .*(2-psi);
H4= .25*(1+psi).^2 .*(psi-1);
xc=(1-psi)/2*x(1) + (1+psi)/2*x(2);
v = H1*q(1) + le/2*H2*q(2) + H3*q(3) + le/2*H4*q(4);
plot(xc,v)
legend('displacement')
