function [] = Example_8_2_heat_conduction()
clear all;close all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
% 4-node mesh
% rectangular region meshing
Lx = 1; Ly = 1;
Ndivx = 4; Ndivy = Ndivx;
ne = Ndivx*Ndivy
nn = (Ndivx+1)*(Ndivy+1)
Le = 1/Ndivx;
%coordinates
for i=1:Ndivy+1    
  for j=1:Ndivx+1
     n=(i-1)*(Ndivx+1)+j;
     x(n,1)=(j-1)*(Lx/Ndivx); x(n,2)=(i-1)*(Ly/Ndivy);
  end
end
%connectivity
for i=1:Ndivy
  for j=1:Ndivx
     n=(i-1)*Ndivx+j;
     noc(n,1)=(i-1)*(Ndivx+1)+j; noc(n,2)=noc(n,1)+1; 
     noc(n,3)=noc(n,2)+Ndivx+1; noc(n,4)=noc(n,3)-1;
  end
end
nen = 4;
TC = 1; h = 0.5; Tinf = 0.1; qout = 0;
% right and bottom edges at 1 deg
NU = [1:Ndivx+1]; U(1:Ndivx+1)=1;
for j=1:Ndivy
  i = (Ndivx+1)*(j+1);
  NU(Ndivx+1+j) = i; U(Ndivx+1+j)=1;
end
% analysis
cc = 1/sqrt(3); 
%wip = 1*1;
xip(1,1)=-cc; xip(1,2)=-cc; xip(2,1)=cc; xip(2,2)=-cc;
xip(3,1)=cc; xip(3,2)=cc; xip(4,1)=-cc; xip(4,2)=cc;
S=zeros(nn); R = zeros(nn,1);
for k = 1:ne
  se = zeros(nen);
  xe = x(noc(k,1:nen),1); ye = x(noc(k,1:nen),2);
  for IP=1:4
    psi = xip(IP,1); eta = xip(IP,2);
    N(1)= 0.25*(1-psi)*(1-eta); dN1_dpsi= -0.25*(1-eta); dN1_deta= -0.25*(1-psi);
    N(2) = 0.25*(1+psi)*(1-eta); dN2_dpsi= 0.25*(1-eta); dN2_deta= -0.25*(1+psi);
    N(3) = 0.25*(1+psi)*(1+eta); dN3_dpsi= 0.25*(1+eta); dN3_deta= 0.25*(1+psi); 
    N(4) = 0.25*(1-psi)*(1+eta); dN4_dpsi= -0.25*(1+eta); dN4_deta= 0.25*(1-psi);
    N = [N(1) N(2) N(3) N(4)];
    dN_dpsi = [dN1_dpsi dN2_dpsi dN3_dpsi dN4_dpsi];
    dN_deta = [dN1_deta dN2_deta dN3_deta dN4_deta];
    dx_dpsi = dN_dpsi*xe; dy_dpsi = dN_dpsi*ye;
    dx_deta = dN_deta*xe; dy_deta = dN_deta*ye;
    J = [dx_dpsi dy_dpsi;
         dx_deta dy_deta];
    Jinv = inv(J);
    G = [dN1_dpsi dN2_dpsi dN3_dpsi dN4_dpsi;
         dN1_deta dN2_deta dN3_deta dN4_deta];
    B = Jinv*G;
    se = se + TC*B'*B*det(J); 
  end
  dof = [noc(k,1) noc(k,2) noc(k,3) noc(k,4)];
  S(dof,dof) = S(dof,dof) + se;
end
% convection on left edge
for j=1:Ndivy
  n = 1+(j-1)*Ndivx;
  dof = [noc(n,1) noc(n,4)];
  hmat = Le*h/6*[2 1;1 2]; rinf = h*Tinf*Le/2*[1 1]';
  S(dof,dof) = S(dof,dof) + hmat;
  R(dof,1)=R(dof,1)+rinf;
end
% specified heat flux on top edge
for j=1:Ndivx
  n = Ndivx*(Ndivy-1) + j;
  dof = [noc(n,3) noc(n,4)];
  rq = -qout*Le/2*[1 1]';
  R(dof,1)=R(dof,1)+rq;
end
% solve with SPCs
dof_free = setdiff(1:nn,NU);
S1 = S(dof_free,dof_free); R1=R(dof_free,1);
for i=1:length(NU)
  j = NU(i);
  R1 = R1 - U(i)*S(dof_free,j);
end
T1 = S1\R1;
T=zeros(nn,1);
T(NU,1)=U;
T(dof_free,1) = T1;
% contour plotting
[x1,x2]=meshgrid(0:Le:1,0:Le:1);
for ir=1:Ndivx+1
  for ic=1:Ndivx+1
    n1 = (ir-1)*(Ndivx+1)+ic;
    z(ir,ic) = T(n1);
  end
end
contour(x1,x2,z,'ShowText','on','linewidth',1.5,'color','k')








