function [] = Example10_4_beam_modes()
clear all; close all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
ne = 2; nn=3;
nq = 2*nn;
X = [0 300e-3 600e-3];
noc = [1 2;
       2 3];
E = 200e9; I = 2000e-12; A = 240e-6; rho = 7840; L = X(3);
ND = 2; NU = [1 2]; U(1:ND)=0;
% stiffness and mass assembly
IFL = 1 % <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< choose mass matrix type
K = zeros(nq); M = zeros(nq);
for i=1:ne
  i1 = noc(i,1); i2 = noc(i,2);
  x1 = X(i1); x2=X(i2);
  Le = abs(x2-x1);
  k = E*I/Le^3*[12    6*Le   -12   6*Le;
                6*Le  4*Le^2 -6*Le 2*Le^2;
                -12  -6*Le    12   -6*Le;
                6*Le  2*Le^2 -6*Le 4*Le^2];
  dof = [2*i1-1 2*i1 2*i2-1 2*i2];
  K(dof,dof) = K(dof,dof) + k;
  if IFL==1
    % consistent
    m = rho*A*Le/420*[156    22*Le    54      -13*Le;
                       22*Le  4*Le^2   13*Le   -3*Le^2;
                       54     13*Le    156     -22*Le;
                       -13*Le -3*Le^2  -22*Le   4*Le^2];
  elseif IFL==2
    % lumped I
    m = zeros(4); 
    m(1,1) = rho*A*Le/2; m(3,3)=m(1,1);
  elseif IFL==3
    % lumped II
    m = zeros(4); 
    m(1,1) = rho*A*Le/2; m(3,3)=m(1,1);
    m(2,2) = rho*A*Le*Le^2/78; m(4,4)=m(2,2);
  end
  M(dof,dof) = M(dof,dof) + m;                 
end
% BCs via elimination technique
dof_free = setdiff([1:nq],NU);
Kfree = K(dof_free,dof_free); Mfree = M(dof_free,dof_free);
[V,D] = eig(Kfree,Mfree);
freq_fea = sqrt(diag(D))/2/pi
% exact frequencies, cps [NASA report, page 3-124]
s = sqrt(E*I/rho/A);
cc =[0.56 3.507 9.819];
freq_exact  = cc*s/L^2
% plot of FEA obtained mode shapes 1,2 
hold
for m=1:2
 Vfull = zeros(nq,1); Vfull(dof_free,1)=V(:,m); Vfull(NU,1)=U;
 for i=1:ne
  i1 = noc(i,1); i2 = noc(i,2);
  x1 = X(i1); x2=X(i2);
  le = abs(x2-x1);
  dof = [2*i1-1 2*i1 2*i2-1 2*i2];
  q = Vfull(dof,1);
  psi=[-1:.1:1];
  H1= .25*(1-psi).^2 .*(2+psi); H2= .25*(1-psi).^2 .*(psi+1);
  H3= .25*(1+psi).^2 .*(2-psi); H4= .25*(1+psi).^2 .*(psi-1);
  xc=(1-psi)/2*x1 + (1+psi)/2*x2;
  v = H1*q(1) + le/2*H2*q(2) + H3*q(3) + le/2*H4*q(4);
  if m==1
    s1 = 'k';
  elseif m==2
    s1 = 'k--';
  end
  h(m) = plot(xc,v,s1);
 end
end
str = {num2str(freq_fea(1)),num2str(freq_fea(2))}; 
legend(h,str)

