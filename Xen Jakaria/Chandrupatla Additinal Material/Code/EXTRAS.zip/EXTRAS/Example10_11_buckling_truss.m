function [] = Example10_11_buckling_truss()
close all; clear all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
iprob=1
if (iprob==1)
ne = 2; nn=3; nq=2*nn;
X = [0.25 0.5;
     0.3  0;
     0  0];
noc = [1 3;
       1 2];
E = 200e9*ones(1,ne); A = 1e-6*ones(1,ne);
F = 1000*[1 2 0 0 0 0]';
dof_free = [1 2]; % BCs
elseif (iprob==2)
ne = 6; nn=5; nq=2*nn;
X = [1 0;
     0.5 0.25;
     0.5 0;
     0 0.5;
     0 0];    
noc = [5 3;
       5 2;
       4 2;
       3 1;
       2 1;
       3 2];
E = 70e9*ones(1,ne); A = .01^2*ones(ne,1);
F = zeros(nq,1); F(2)= -50;
dof_free = [1 2 3 4 5 6]; % BCs
end
% stiffness assembly
K = zeros(2*nn); 
for i=1:ne
  i1 = noc(i,1); i2 = noc(i,2);
  x1 = X(i1,1); x2=X(i2,1); 
  y1 = X(i1,2); y2=X(i2,2);
  Le = sqrt((x2-x1)^2+(y2-y1)^2);
  el = (x2-x1)/Le; em = (y2-y1)/Le;
  L = [el em 0  0 ;
       0  0  el em];
  klocal = E(i)*A(i)/Le*[1 -1;
                        -1 1];
  k = L'*klocal*L;
  dof = [2*i1-1 2*i1 2*i2-1 2*i2];
  K(dof,dof) = K(dof,dof) + k;
end
% BCs via elimination technique
Kfree = K(dof_free,dof_free);
% stress analysis to get axial forces
Ffree = F(dof_free,1);
Qfree = Kfree\Ffree;
Q = zeros(nq,1);
Q(dof_free)=Qfree;
%Q
for i=1:ne
  i1 = noc(i,1); i2 = noc(i,2);
  x1 = X(i1,1); x2=X(i2,1); 
  y1 = X(i1,2); y2=X(i2,2);
  Le = sqrt((x2-x1)^2+(y2-y1)^2);
  el = (x2-x1)/Le; em = (y2-y1)/Le;
  L = [-el -em el em];
  dof = [2*i1-1 2*i1 2*i2-1 2*i2];
  q = Q(dof,1);
  s(i) = E(i)/Le*L*q*A(i);  % element force = stress x area
end
s
KG = zeros(2*nn);
% geometric stiffness assembly
for i=1:ne
  i1 = noc(i,1); i2 = noc(i,2);
  x1 = X(i1,1); x2=X(i2,1); 
  y1 = X(i1,2); y2=X(i2,2);
  Le = sqrt((x2-x1)^2+(y2-y1)^2);
  el = (x2-x1)/Le; em = (y2-y1)/Le;
  dof = [2*i1-1 2*i1 2*i2-1 2*i2];
  K(dof,dof) = K(dof,dof) + k;
  kgp = -s(i)/Le*[0 0 0 0;
                 0 1 0 -1;
                 0 0 0 0;
                 0 -1 0 1];
  T = [el em 0 0;
       -em el 0 0;
       0 0 el em;
       0 0 -em el];
  kg = T'*kgp*T;
  KG(dof,dof) = KG(dof,dof) + kg;  
end
KGfree = KG(dof_free,dof_free);
[V,D] = eigs(Kfree,KGfree,1,'sm')








