function [] = Example_6_7_body_force_quad()
clear all;close all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
t = 1; cc = 1/sqrt(3); wip = 1*1;
xip(1,1)=-cc; xip(1,2)=-cc; xip(2,1)=cc; xip(2,2)=-cc;
xip(3,1)=cc; xip(3,2)=cc; xip(4,1)=-cc; xip(4,2)=cc;
f = [0 0 0 0];
for IP=1:4
psi = xip(IP,1); eta = xip(IP,2);
N(1)= 0.25*(1-psi)*(1-eta); dN1_dpsi= -0.25*(1-eta); dN1_deta= -0.25*(1-psi);
N(2) = 0.25*(1+psi)*(1-eta); dN2_dpsi= 0.25*(1-eta); dN2_deta= -0.25*(1+psi);
N(3) = 0.25*(1+psi)*(1+eta); dN3_dpsi= 0.25*(1+eta); dN3_deta= 0.25*(1+psi); 
N(4) = 0.25*(1-psi)*(1+eta); dN4_dpsi= -0.25*(1+eta); dN4_deta= 0.25*(1-psi);
N = [N(1) N(2) N(3) N(4)];
dN_dpsi = [dN1_dpsi dN2_dpsi dN3_dpsi dN4_dpsi];
dN_deta = [dN1_deta dN2_deta dN3_deta dN4_deta];
x1=2;x2=2;x3=0;x4=0;
y1=0; y2=1; y3=1; y4=0;
xe = [x1 x2 x3 x4]'; ye = [y1 y2 y3 y4]';
x = N*xe; y = N*ye;
dx_dpsi = dN_dpsi*xe; dy_dpsi = dN_dpsi*ye;
dx_deta = dN_deta*xe; dy_deta = dN_deta*ye;
J = [dx_dpsi dy_dpsi;
     dx_deta dy_deta];
detJ = det(J);
f = f + t*N*x*det(J)*wip;
end
f