function [] = invitr_simple_code()
clear all; close all;
disp('***************************************');
disp('*PROGRAM SIMPLE VER. OF INV. ITERATRION');
disp('* T.R.Chandrupatla and A.D.Belegundu 	*');
disp('***************************************');      

n=3;
K = 600*[1 -1  0;
        -1  3 -2;
         0 -2  5];
M = [1  0   0;
     0 1.5  0;
     0  0   2];
uk = ones(1,n)'; %starting guess
itermax = 10; tol = 1e-6;
iter=0;
while 1
  iter=iter+1; 
  if iter>itermax
    break
  end
  % orthogonal to previously found mode shape(s) <<<<<<<<<<<<<<<<<<<<<
  % V1 = [0.7426 0.4817 0.2242]';
  % uk = uk - (uk'*M*V1)*V1;
  %
  ukp1hat = K\(M*uk);
  lambdakp1 = (ukp1hat'*K*ukp1hat)/(ukp1hat'*M*ukp1hat);
  if iter>1
    if abs(lambdakp1-lambda_prev)/abs(lambdakp1) <= tol
        break
    end
  end
  ukp1 = ukp1hat/sqrt(ukp1hat'*M*ukp1hat);
  uk = ukp1; lambda_prev = lambdakp1;
end
eigenvalue = lambdakp1
freq_cps = sqrt(lambdakp1)/2/pi
ukp1

  
