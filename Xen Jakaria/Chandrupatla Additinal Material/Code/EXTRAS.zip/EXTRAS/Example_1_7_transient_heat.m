function [] = Example_1_7_transient_heat()
close all; clear all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
global alp uinf L h k
alp = 33.9e-6; uinf = 450; h = 120; k=110; L = 2e-2; u0=25;
tau = 40*60; % sec
[t1,y] = ode45(@odefun,[0 tau],[u0 0]);
usurf_t= y(:,1) + L*y(:,2);
usurf_8min = interp1(t1,usurf_t,8*60)
plot(t1,usurf_t,'b')
hold
plot([480 480],[0 300]);
legend('surface temperature');

function [f] = odefun(t,y)
global alp uinf L h k
M = L/alp*[1 L/2;L/2 L^2/3];
K = -[h/k h*L/k;h*L/k (L+h*L^2/k)];
F = h/k*uinf*[1 L]';
f = inv(M)*(K*y+F);

