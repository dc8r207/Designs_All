function [] = Example_8_5_coaxial_cable()
clear all;close all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
% 4-node mesh - square coaxial cable
nen = 4;
TC = 1;
[ne,nn,x,noc,NU,U,nsetx,nsety] = inputdata;
% analysis
cc = 1/sqrt(3); 
%wip = 1*1;
xip(1,1)=-cc; xip(1,2)=-cc; xip(2,1)=cc; xip(2,2)=-cc;
xip(3,1)=cc; xip(3,2)=cc; xip(4,1)=-cc; xip(4,2)=cc;
S=zeros(nn); R = zeros(nn,1);
for k = 1:ne
  se = zeros(nen);
  xe = x(noc(k,1:nen),1); ye = x(noc(k,1:nen),2);
  for IP=1:4
    psi = xip(IP,1); eta = xip(IP,2);
    N(1)= 0.25*(1-psi)*(1-eta); dN1_dpsi= -0.25*(1-eta); dN1_deta= -0.25*(1-psi);
    N(2) = 0.25*(1+psi)*(1-eta); dN2_dpsi= 0.25*(1-eta); dN2_deta= -0.25*(1+psi);
    N(3) = 0.25*(1+psi)*(1+eta); dN3_dpsi= 0.25*(1+eta); dN3_deta= 0.25*(1+psi); 
    N(4) = 0.25*(1-psi)*(1+eta); dN4_dpsi= -0.25*(1+eta); dN4_deta= 0.25*(1-psi);
    N = [N(1) N(2) N(3) N(4)];
    dN_dpsi = [dN1_dpsi dN2_dpsi dN3_dpsi dN4_dpsi];
    dN_deta = [dN1_deta dN2_deta dN3_deta dN4_deta];
    dx_dpsi = dN_dpsi*xe; dy_dpsi = dN_dpsi*ye;
    dx_deta = dN_deta*xe; dy_deta = dN_deta*ye;
    J = [dx_dpsi dy_dpsi;
         dx_deta dy_deta];
    Jinv = inv(J);
    G = [dN1_dpsi dN2_dpsi dN3_dpsi dN4_dpsi;
         dN1_deta dN2_deta dN3_deta dN4_deta];
    B = Jinv*G;
    se = se + TC*B'*B*det(J); 
  end
  dof = [noc(k,1) noc(k,2) noc(k,3) noc(k,4)];
  S(dof,dof) = S(dof,dof) + se;
end
% solve with SPCs
dof_free = setdiff(1:nn,NU);
S1 = S(dof_free,dof_free); R1=R(dof_free,1);
for i=1:length(NU)
  j = NU(i);
  R1 = R1 - U(i)*S(dof_free,j);
end
T1 = S1\R1;
T=zeros(nn,1);
T(NU,1)=U;
T(dof_free,1) = T1;
%compute impedance
Intx = 0;
for i=1:length(nsetx)
  n = nsetx(i);
  dof = [noc(n,1) noc(n,2) noc(n,3) noc(n,4)];
  Le = abs(x(noc(n,2),2)-x(noc(n,3),2));
  Te = T(dof,1);
  dTdx = 0;
  for IP=1:4
    if (IP==1 | IP==4)
    psi = xip(IP,1); eta = xip(IP,2);
    N(1)= 0.25*(1-psi)*(1-eta); dN1_dpsi= -0.25*(1-eta); dN1_deta= -0.25*(1-psi);
    N(2) = 0.25*(1+psi)*(1-eta); dN2_dpsi= 0.25*(1-eta); dN2_deta= -0.25*(1+psi);
    N(3) = 0.25*(1+psi)*(1+eta); dN3_dpsi= 0.25*(1+eta); dN3_deta= 0.25*(1+psi); 
    N(4) = 0.25*(1-psi)*(1+eta); dN4_dpsi= -0.25*(1+eta); dN4_deta= 0.25*(1-psi);
    N = [N(1) N(2) N(3) N(4)];
    dN_dpsi = [dN1_dpsi dN2_dpsi dN3_dpsi dN4_dpsi];
    dN_deta = [dN1_deta dN2_deta dN3_deta dN4_deta];
    dx_dpsi = dN_dpsi*xe; dy_dpsi = dN_dpsi*ye;
    dx_deta = dN_deta*xe; dy_deta = dN_deta*ye;
    J = [dx_dpsi dy_dpsi;
         dx_deta dy_deta];
    Jinv = inv(J);
    G = [dN1_dpsi dN2_dpsi dN3_dpsi dN4_dpsi;
         dN1_deta dN2_deta dN3_deta dN4_deta];
    B = Jinv*G;
    dTdx = dTdx + B(1,:)*Te;
    end
  end
  Intx = Intx + 0.5*dTdx*Le;
end
Inty = 0;
for i=1:length(nsety)
  n = nsety(i);
  dof = [noc(n,1) noc(n,2) noc(n,3) noc(n,4)];
  Le = abs(x(noc(n,1),1)-x(noc(n,2),1));
  Te = T(dof,1);
  dTdy = 0;
  for IP=1:4
    if (IP==1 | IP==2)
    psi = xip(IP,1); eta = xip(IP,2);
    N(1)= 0.25*(1-psi)*(1-eta); dN1_dpsi= -0.25*(1-eta); dN1_deta= -0.25*(1-psi);
    N(2) = 0.25*(1+psi)*(1-eta); dN2_dpsi= 0.25*(1-eta); dN2_deta= -0.25*(1+psi);
    N(3) = 0.25*(1+psi)*(1+eta); dN3_dpsi= 0.25*(1+eta); dN3_deta= 0.25*(1+psi); 
    N(4) = 0.25*(1-psi)*(1+eta); dN4_dpsi= -0.25*(1+eta); dN4_deta= 0.25*(1-psi);
    N = [N(1) N(2) N(3) N(4)];
    dN_dpsi = [dN1_dpsi dN2_dpsi dN3_dpsi dN4_dpsi];
    dN_deta = [dN1_deta dN2_deta dN3_deta dN4_deta];
    dx_dpsi = dN_dpsi*xe; dy_dpsi = dN_dpsi*ye;
    dx_deta = dN_deta*xe; dy_deta = dN_deta*ye;
    J = [dx_dpsi dy_dpsi;
         dx_deta dy_deta];
    Jinv = inv(J);
    G = [dN1_dpsi dN2_dpsi dN3_dpsi dN4_dpsi;
         dN1_deta dN2_deta dN3_deta dN4_deta];
    B = Jinv*G;
    dTdy = dTdy + B(2,:)*Te;
    end
  end
  Inty = Inty + 0.5*dTdy*Le;
end
Int1 = Intx+Inty;
% E = -del(V); 1/4-symmetry
Z = 377*1/(-4*Int1)





function [ne,nn,x,noc,NU,U,nsetx,nsety] = inputdata
FILE1 = 'Example8_5.dat';
LINP  = fopen(FILE1,'r');
DUMMY = fgets(LINP);
TITLE = fgets(LINP);
DUMMY = fgets(LINP);
TMP = str2num(fgets(LINP));
[NN, NE, NM, NDIM, NEN, NDN] = deal(TMP(1),TMP(2),TMP(3),TMP(4),TMP(5),TMP(6));
nn=NN; ne=NE;
DUMMY = fgets(LINP);
TMP = str2num(fgets(LINP));
[ND, NL, NMPC]= deal(TMP(1),TMP(2),TMP(3));

%----- Coordinates -----
DUMMY = fgets(LINP);
for I=1:NN
   TMP = str2num(fgets(LINP));
   [j,x(j,1),x(j,2)] = deal(TMP(1),TMP(2), TMP(3));
end
%----- Connectivity -----
DUMMY = fgets(LINP);
for J=1:NE
   TMP = str2num(fgets(LINP));
   [I,noc(I,:)] = ...
      deal(TMP(1),TMP(2:NEN+1));
end
close;
% **************** BCs **************************
% nsetx = [17 21 25 29]; nsety = [33 34 35 36];
% NU1 = [[1:5],[10:14],[19:23],[28:32],[37:41]]; 
% lenU1 = length(NU1);
% for i=1:lenU1
%   NU(i)=NU1(i); U(i)=1;
% end
% NU2 = [[73:81],[9:9:80]];
% for i=1:length(NU2)
%   NU(i+lenU1)=NU2(i); U(i+lenU1)=0;
% end
%***********************************************
ndiv = 4;  % based on Example8_5.dat !!
NU1=[];
for i=1:ndiv+1
  j = 1+(2*ndiv+1)*(i-1);
  NU1 = union(NU1,[j:j+ndiv]);
end
lenU1 = length(NU1);
for i=1:lenU1
  NU(i)=NU1(i); U(i)=1;
end
NU2 = [(2*ndiv+1)*2*ndiv+1:(2*ndiv+1)^2, (2*ndiv+1)*[1:2*ndiv]];
for i=1:length(NU2)
  NU(i+lenU1)=NU2(i); U(i+lenU1)=0;
end
k = ndiv/2+1;
for i=1:ndiv+k-1
  if i>ndiv
    nsetx(i) = 3*ndiv^2+k+ndiv*(i-ndiv-1);
  else
    nsetx(i) = ndiv^2+k+ndiv*(i-1);
  end
end
for i=1:ndiv+k-1
  if i>ndiv
    nsety(i) = 3*ndiv^2+(i-ndiv)+(k-1)*ndiv;
  else
    nsety(i) = 2*ndiv^2+i+(k-1)*ndiv;
  end
end





