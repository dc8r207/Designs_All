function [] = DKT_freq()
clear all;close all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu 

global ilumped
ilumped = 1
% q = [w1, dw/dy1, -dw/dx1, w2, ...]'  (9x1)
[NN,NE,NEN,NDN,ND,X,NOC,MAT,F,NU,U,PM] = InputData;
NQ = NDN*NN;
GK=zeros(NQ); GM=zeros(NQ);
IFL = 0;
for N = 1:NE
  [EK,EM] = DKT_stiffness(N, MAT, PM, X, NOC);
  i1 = NOC(N,1); i2 = NOC(N,2); i3 = NOC(N,3);
  dof = [3*i1-2 3*i1-1 3*i1 3*i2-2 3*i2-1 3*i2 3*i3-2 3*i3-1 3*i3];
  GK(dof,dof) = GK(dof,dof) + EK;
  GM(dof,dof) = GM(dof,dof) + EM;
end

% BCs via elimination technique
dof_free = setdiff([1:NQ],NU);
K = GK(dof_free,dof_free); M = GM(dof_free,dof_free);
p = 7
[V,D] = eigs(K,M,p,'sm');
freq_fea = sqrt(diag(D))/2/pi
Vfull = zeros(3*NQ,p); 
for j=1:p
  Vfull(dof_free,j)=V(:,j);
end
%plot
Ndivx = sqrt(NE/2);
[x1,x2]=meshgrid(0:1/Ndivx:1,0:1/Ndivx:1);
for ir=1:Ndivx+1
  for ic=1:Ndivx+1
    n1 = (ir-1)*(Ndivx+1)+ic;
    % plot mode shape # 'pp'
    pp = 4;
    z(ir,ic) = Vfull(3*n1-2,pp);
  end
end
figure(1)
contour(x1,x2,z,'ShowText','on','linewidth',1.5,'color','k')
figure(2)
mesh(x1,x2,z,'EdgeColor','black')


% exact frequencies, cps [NASA report, page 3-176]
% thickness, side length in inches
h = 0.5/2.54; a = 100/2.54;
% four corner point simply supported
Cn = [6.91 15.29 18.6 37.35 42.28];
% CCFF supported
%Cn = [6.77 23.43 26.07 46.75];
fn = Cn*h/a^2*1e4


function [EK,EM] = DKT_stiffness(N, MAT, PM, X, NOC)
global ilumped
matno = MAT(N);
TH = PM(matno,4); E = PM(matno,1); PNU = PM(matno,2); RHO = PM(matno,3); 
C1 = E / (1 - PNU ^ 2);
C2 = C1 * PNU;
C3 = .5 * E / (1 + PNU);     
D = [C1 C2 0.
     C2 C1 0.
     0. 0. C3];
NIP=3;
WT(1:NIP)=1/6;
XNI(1,1)=1/2; XNI(1,2)=1/2; 
XNI(2,1)=0;   XNI(2,2)=1/2;
XNI(3,1)=1/2; XNI(3,2)=0;
EK=zeros(9); fe = zeros(9,1);
I1 = NOC(N,1);I2 = NOC(N,2);I3 = NOC(N,3);
T = zeros(6,9);   
for I=1:3
  J1=I;
  J2=I+1;
  if(I==3)
    J2=1;
  end
  XX1=X(NOC(N,J1),1); XX2=X(NOC(N,J2),1);
  YY1=X(NOC(N,J1),2); YY2=X(NOC(N,J2),2);
  L12=sqrt( (XX2-XX1)^2+(YY2-YY1)^2 );
  S1= (XX2-XX1)/L12; S2= (YY2-YY1)/L12;
  T(2*I-1,3*J1-2)=-1.5*S1/L12;
  T(2*I-1,3*J1-1)=-0.75*S1*S2;
  T(2*I-1,3*J1)=.25*S1*S1-.5*S2*S2;
  T(2*I-1,3*J2-2)=1.5*S1/L12;
  T(2*I-1,3*J2-1)=-0.75*S1*S2;
  T(2*I-1,3*J2)=.25*S1*S1-.5*S2*S2;
  T(2*I,3*J1-2)=-1.5*S2/L12;
  T(2*I,3*J1-1)=-.25*S2*S2+.5*S1*S1;
  T(2*I,3*J1)=.75*S1*S2;
  T(2*I,3*J2-2)=1.5*S2/L12;
  T(2*I,3*J2-1)=-.25*S2*S2+.5*S1*S1;
  T(2*I,3*J2)=.75*S1*S2;
end
for IP=1:NIP
  XI = XNI(IP,1); ETA=XNI(IP,2); ZETA=1-XI-ETA;      
  J11=X(I1,1) - X(I3,1); J12=X(I1,2) - X(I3,2); 
  J21=X(I2,1) - X(I3,1); J22=X(I2,2) - X(I3,2);
  DETJ = J11*J22 - J21*J12;
  A(1,1)=J22/DETJ;
  A(1,2)=-J12/DETJ;
  A(1,3)=0.;
  A(1,4)=0.;
  A(2,1)=0.;
  A(2,2)=0.;
  A(2,3)=-J21/DETJ;
  A(2,4)=J11/DETJ;
  A(3,1)=-J21/DETJ;
  A(3,2)=J11/DETJ;
  A(3,3)=J22/DETJ;
  A(3,4)=-J12/DETJ;    
  DS(1,1)=4*XI-1; DS(1,2)=0;
  DS(2,1)=0; DS(2,2)=4*ETA-1;
  DS(3,1)=1-4*ZETA; DS(3,2)=1-4*ZETA;
  DS(4,1)=4*ETA;DS(4,2)=4*XI;
  DS(5,1)=-4*ETA;DS(5,2)=4*(1-XI-2*ETA);
  DS(6,1)=4*(1-2*XI-ETA);DS(6,2)=-4*XI;      
  AA = zeros(4,9);
  for I=1:2
    for J=1:3
      for K=1:9
        AA(I,K)=AA(I,K)+DS(3+J,I)*T(2*J-1,K);
	  end
      AA(I,3*J)=AA(I,3*J)-DS(J,I);
    end
  end    
  for I=1:2
    for J=1:3
      for K=1:9
        AA(2+I,K)=AA(2+I,K)+DS(3+J,I)*T(2*J,K);
      end
      AA(2+I,3*J-1)=AA(2+I,3*J-1)+DS(J,I);
    end
  end      
  BBEND = A*AA;
  DB = D*BBEND;
  EK = EK + TH^3/12*BBEND'*DB*DETJ*WT(IP);
  
end   %end loop NIP

% mass matrix
x1=X(I1,1); x2=X(I2,1); x3=X(I3,1); y1=X(I1,2); y2=X(I2,2); y3=X(I3,2);
[Nhat] = GetShapeFn(x1,y1,x2,y2,x3,y3);
J = [x1-x3 y1-y3;x2-x3 y2-y3];
EM = zeros(9); %EM2 = zeros(9);
if ilumped~=1
  for IP=1:NIP
    xi = XNI(IP,1); eta=XNI(IP,2); zeta=1-xi-eta;
    x = xi*x1 +eta*x2+zeta*x3; y = xi*y1 +eta*y2+zeta*y3;
    P = [1 x y x^2 y^2 x^3 x^2*y x*y^2 y^3];
    EM = EM + RHO*TH*P'*P*det(J)*WT(IP);
    % in-plane contribution
%     TM1 = [0 0 -xi 0 0 -eta 0 0 -zeta] + ...
%           4*xi*eta*T(1,:) + 4*zeta*eta*T(3,:) + 4*xi*zeta*T(5,:);
%     TM2 = [0 xi 0 0 eta 0 0 zeta 0] + ...
%           4*xi*eta*T(2,:) + 4*zeta*eta*T(4,:) + 4*xi*zeta*T(6,:);
%     TM = [TM1; TM2];
%     EM2 = EM2 + RHO*TH^3/12*TM'*TM*DETJ*WT(IP);
  end
  A0 = inv(Nhat);
  EM = A0'*EM*A0;
  %EM = EM + EM2;
else
  cc = RHO*TH*0.5*det(J);
  EM(1,1) = cc/3; EM(4,4) = cc/3; EM(7,7) = cc/3;
end
 


   %------------------------  function InputData  ---------------------------
function [NN,NE,NEN,NDN,ND,X,NOC,MAT,F,NU,U,PM] = InputData()
global NN NE NM NDIM NEN NDN
global ND NL NCH NPR NMPC NBW
global X NOC F AREA MAT TH DT S
global PM NU U MPC BT STRESS REACT
global CNST
global TITLE FILE1 FILE2
global LINP LOUT LOUT2
global NQ
global LC IPL


disp(blanks(1));
FILE1 = 'plate_ss4c.inp';
%FILE1 = 'plate_CCFF.inp';

LINP  = fopen(FILE1,'r');

DUMMY = fgets(LINP);
TITLE = fgets(LINP);
DUMMY = fgets(LINP);
TMP = str2num(fgets(LINP));
[NN, NE, NM, NDIM, NEN, NDN] = deal(TMP(1),TMP(2),TMP(3),TMP(4),TMP(5),TMP(6));

NQ = NDN * NN;

DUMMY = fgets(LINP);
TMP = str2num(fgets(LINP));
[ND, NL, NMPC]= deal(TMP(1),TMP(2),TMP(3));

NPR = 5;  %E, NU,  RHO, THICK, UDL

%----- Coordinates -----
DUMMY = fgets(LINP);
for I=1:NN
   TMP = str2num(fgets(LINP));
   [N, X(N,:)]=deal(TMP(1),TMP(2:1+NDIM));
end
%----- Connectivity -----
DUMMY = fgets(LINP);
for I=1:NE
   TMP = str2num(fgets(LINP));
   [N,NOC(N,:), MAT(N,:)] = ...
      deal(TMP(1),TMP(2:1+NEN), TMP(2+NEN));
end

%----- Specified Displacements -----
DUMMY = fgets(LINP);
for I=1:ND
   TMP = str2num(fgets(LINP));
   [NU(I),U(I)] = deal(TMP(1), TMP(2));
end
%----- Component Loads -----
DUMMY = fgets(LINP);
F = zeros(NQ,1);
for I=1:NL
   TMP = str2num(fgets(LINP));
   [N,F(N)]=deal(TMP(1),TMP(2));
end

%----- "Material Card" -----
DUMMY = fgets(LINP);
for I=1:NM
   TMP = str2num(fgets(LINP));
   [N, PM(N,:)] = deal(TMP(1), TMP(2:NPR+1));
end
%----- Multi-point Constraints B1*Qi+B2*Qj=B0
if NMPC > 0
   DUMMY = fgets(LINP);
   for I=1:NMPC
   	TMP = str2num(fgets(LINP));
      [BT(I,1), MPC(I,1), BT(I,2), MPC(I,2), BT(I,3)] = ...
         			deal(TMP(1),TMP(2),TMP(3),TMP(4),TMP(5));
   end
end
fclose(LINP);




function [N] = GetShapeFn(x1,y1,x2,y2,x3,y3)
% w = [1 x y x^2 y^2 x^3 x^2.y x.y^2 y^3]*[a1, a2, ..., a9]'
% order: w,dw/dy,-dw/dx
N(1,:) = [1 x1 y1 x1^2 y1^2 x1^3 x1^2*y1 x1*y1^2 y1^3];
N(2,:) = [0 0 1 0 2*y1 0 x1^2 2*x1*y1 3*y1^2];
N(3,:) = -[0 1 0 2*x1 0 3*x1^2 2*x1*y1 y1^2 0];
N(4,:) = [1 x2 y2 x2^2 y2^2 x2^3 x2^2*y2 x2*y2^2 y2^3];
N(5,:) = [0 0 1 0 2*y2 0 x2^2 2*x2*y2 3*y2^2];
N(6,:) = -[0 1 0 2*x2 0 3*x2^2 2*x2*y2 y2^2 0];
N(7,:) = [1 x3 y3 x3^2 y3^2 x3^3 x3^2*y3 x3*y3^2 y3^3];
N(8,:) = [0 0 1 0 2*y3 0 x3^2 2*x3*y3 3*y3^2];
N(9,:) = -[0 1 0 2*x3 0 3*x3^2 2*x3*y3 y3^2 0];

