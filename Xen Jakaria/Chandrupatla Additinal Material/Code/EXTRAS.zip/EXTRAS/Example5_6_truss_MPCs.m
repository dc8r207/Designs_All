function [] = Example5_6_truss_MPCs()
clear all;close all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
ne = 3; nn=3;
X = [0 0;
    0.5 0.5;
     0 0.5];
noc = [1 2;
       2 3;
       3 1];
E0=100; A0=0.1; P=10; 
E = E0*ones(1,ne); 
Area = A0*[1/2 1 1/2];
F = P/2*[0 0 -1/sqrt(2) -1/sqrt(2) 0 0]'; % externally applied loads
K = zeros(2*nn);
% stiffness assembly
for i=1:ne
  i1 = noc(i,1); i2 = noc(i,2);
  x1 = X(i1,1); x2=X(i2,1); y1 = X(i1,2); y2=X(i2,2);
  Le = sqrt((x2-x1)^2+(y2-y1)^2);
  el = (x2-x1)/Le; em = (y2-y1)/Le;
  L = [el em 0 0;
       0  0  el em];
  klocal = E(i)*Area(i)/Le*[1 -1;
                    -1 1];
  k = L'*klocal*L;
  dof = [2*i1-1 2*i1 2*i2-1 2*i2];
  K(dof,dof) = K(dof,dof) + k;
end
% SPCs 
dof_free = [3 4 6];
Kr = K(dof_free,dof_free); Fr = F(dof_free);
det(Kr)
%MPC
A = [1 0;
     1 0;
     0 1];
Km = A'*Kr*A;
det(Km)
Fm = A'*Fr;
Qm = Km\Fm;
Q1 = A*Qm;
Q = [0 0 Q1(1) Q1(2) 0 Q1(3)]'; 
Q
Ldeformed = 2*(sqrt( (.5+Q(3))^2+(.5+Q(4))^2 ))
Lformula = sqrt(2)*(1-2*.2071*P/E0/A0)


