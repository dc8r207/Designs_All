function []=Cuthill_McKee();
close all;clear all;

%*****  Cuthill_McKee algorith for Bandwidth Reduction *****
%                   Symmetric Matrices
disp('***************************************');
disp('*          PROGRAM CUTHILL-MCKEE      *');
disp('* T.R.Chandrupatla and A.D.Belegundu 	*');
disp('***************************************'); 
% written by A.D. Belegundu 2020

% input adjacency matrix
iprob = 1
start_node = 3  % start with a approx_peripheral node
IFL_reverse_CM = 1
[n,A] = inputdata(iprob);
disp('A = ')
for i=1:n
  disp(sprintf('%2d',[A(i,:)]));
end
%**************************************************************************
incid = sum(A)  % vertex incidence count
% initial bandwidth
init_set = [1:n];
nbw = bandwidth(n,A,init_set);
disp(sprintf('\n initial bandwidth = %4d',nbw));
[profile_init] = profile(n,A);
disp(sprintf('  initial profile = %4d',profile_init));

k=1; LS = 1; pointer(1) = 1;
iperm(1) = start_node; iperm2(start_node) = 1;
S_marked = [start_node]; % set of marked indices belonging to level sets i-1 & i
S_i_1 = [start_node];
while k < n
for i = 1:length(S_i_1)
  if i==1
    S_i = [];
  end
  adj = find(A(S_i_1(i),:));
  S = setdiff(adj,S_marked);
  S_i = [S_i  S];
  [cc,ix] = sort(incid(S));
  S = S(ix);
  for j = 1:length(S)
    k=k+1; iperm(k) = S(j); iperm2(S(j)) = k;
    S_marked = [S_marked  S(j)];
  end
end
[cc,ix] = sort(incid(S_i));
S_i = S_i(ix);
S_i_1 = S_i; LS=LS+1; pointer(LS) = pointer(LS-1) + length(S_i);
end

disp(' ')
pointer
disp(sprintf('\n # level sets = %4d',LS));
disp('old nos')
disp(sprintf('%4d',[iperm(1:n)]));
disp('new nos - CM')
disp(sprintf('%4d',[1:n]));
disp(' ')
disp('** alternate output **')
disp(' ')
disp('new nos - CM')
disp(sprintf('%4d',[iperm2(1:n)]));
disp('old nos')
disp(sprintf('%4d',[1:n]));
nbw = bandwidth(n,A,iperm);
disp(sprintf('\n bandwidth CM = %4d',nbw));
B = A(iperm,iperm);
[profile_CM] = profile(n,B);
disp(sprintf('  profile_CM = %4d \n',profile_CM));
disp('A = as per CM ')
for i=1:n
  disp(sprintf('%2d',[B(i,:)]));
end
% reverse Cuthill-McKee
if IFL_reverse_CM > 0
  iperm_RCM = flip(iperm);
  for i=1:n
    iperm2_RCM(iperm_RCM(i))=i;
  end
  disp(' ')  
  disp('old nos')
  disp(sprintf('%4d',[iperm_RCM(1:n)]));
  disp('new nos - RCM')
  disp(sprintf('%4d',[init_set(1:n)]));
  disp(' ')
  disp('** alternate output **')
  disp(' ')
  disp('new nos - RCM')
  disp(sprintf('%4d',[iperm2_RCM(1:n)]));
  disp('old nos')
  disp(sprintf('%4d',[init_set(1:n)]));
  %
  nbw = bandwidth(n,A,iperm_RCM);
  disp(sprintf('\n bandwidth RCM = %4d',nbw));
  for i=1:n
    for j=1:n
      B(i,j)=A(iperm_RCM(i),iperm_RCM(j));
    end
  end
  [profile_RCM] = profile(n,B);
  disp(sprintf('profile_RCM = %4d \n',profile_RCM));  
  disp('A = as per RCM ')
  for i=1:n
    disp(sprintf('%2d',[B(i,:)]));
  end
end
% r = symrcm(A)
% nbw = bandwidth(n,A,r)
% B = A(r,r);
% [profile_symrcm] = profile(n,B)



function [nbw] = bandwidth(n,A,iperm)
nbw = 0;
for i=1:n
  sum1=0;
  for j=n:-1:i
    sum1 = sum1 + A(iperm(i),iperm(j));
    if sum1>0
        ii = j-i+1;
        break
    end
  end
  if (ii>nbw)
    nbw=ii;
  end
end

function [p] = profile(n,B)
p = 0;
for j=1:n
  for i=1:j
    if B(i,j) > 0
      p = p+j-i;
      break
    end
  end
end

function [n,A] = inputdata(iprob)
switch(iprob)
    
case 1
    % Example 2.5, Text
n = 11;
A = eye(n);
A(1,6)=1; A(1,10)=1; 
A(2,4)=1; A(2,9)=1; 
A(3,5)=1; A(3,7)=1; A(3,11)=1;
A(4,7)=1;
A(5,8)=1;
A(6,9)=1;
A(7,11)=1;
A(8,11)=1;
A(9,11)=1;
A(10,11)=1;

case 2
n = 8;
A = eye(n);
A(1,5)=1; A(2,6)=1; A(3,4)=1; A(1,8)=1;
A(4,5)=1; A(4,8)=1;
A(5,6)=1; A(5,7)=1;
A(6,8)=1; A(7,8)=1;
    
case 3
n = 4;
A=eye(n);
A(1,:)=[1 1 0 1];
A(2,:)=[1 1 1 0];
A(3,:)=[0 1 1 1];
A(4,:)=[1 0 1 1];

case 4
n = 11;
A = eye(n);
A(1,2)=1; A(1,11)=1; 
A(2,3)=1; 
A(3,4)=1; A(3,6)=1;
A(4,7)=1;
A(5,6)=1; A(5,8)=1; A(5,10)=1;
A(6,8)=1; A(6,9)=1; A(6,11)=1;
A(7,8)=1;
A(9,10)=1;

case 5
% springs - Fig. 2.5, Text
n=6
A=eye(n);
noc(1,:)=[1 2];
noc(2,:)=[2 3];
noc(3,:)=[3 4];
noc(4,:)=[4 5];
noc(5,:)=[5 6];
noc(6,:)=[1 6];
noc(7,:)=[2 5];

% noc(1,:)=[1 3];
% noc(2,:)=[3 5];
% noc(3,:)=[5 6];
% noc(4,:)=[6 4];
% noc(5,:)=[4 2];
% noc(6,:)=[1 2];
% noc(7,:)=[3 4];

ne = 7;
for i=1:ne
    dof = noc(i,:);
    A(dof,dof)=1;
end        
        
case 6
% Duff et al book, eg. page 154
n=7
A=eye(n);
noc(1,:)=[1 7];
noc(2,:)=[2 7];
noc(3,:)=[3 7];
noc(4,:)=[4 7];
noc(5,:)=[5 7];
noc(6,:)=[6 7];
ne = 6;
for i=1:ne
    dof = noc(i,:);
    A(dof,dof)=1;
end


case 7
n=8; A=eye(n);
A(1,2)=1;A(1,5)=1;A(1,8)=1;
A(2,6)=1;
A(3,4)=1;
A(4,5)=1; A(4,8)=1;
A(5,6)=1; A(5,7)=1;
A(6,8)=1;
A(7,8)=1;

end


for i=1:n
  for j=i:n
    A(j,i)=A(i,j);
  end
end









    