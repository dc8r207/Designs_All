function [] = Example_4_5_Galerkin_DiffEq()
close all; clear all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
L = 2;
ne = 4; % no. of finite elements
nn = ne+1; %no. of nodes
le = L/ne;
x = [0:le:L];
% assembly
K = zeros(nn); M=zeros(nn); F = zeros(nn,1);
for n=1:ne
  me = le/6*[2 1;1 2];
  ke = 1/le*[1 -1;-1 1];
  dof = [n n+1];
  K(dof,dof) = K(dof,dof) + me - ke;
  xe = [x(n) x(n+1)]';
  F(dof) = F(dof) + me*xe;
end
%BCs
dof = [2:nn-1];
K1=K(dof,dof); M1=M(dof,dof); F1 = F(dof,1);
uL = 5;
F1 = F1 - uL*K(dof,nn);
u = K1\F1;
uT = [0 u' uL];
plot(x,uT,'--ko')
xticks([0:le:L]);
hold
xcoord = [0:.1:L]; fexact = 3/sin(2)*sin(xcoord) + xcoord;
plot(xcoord,fexact,'k','linewidth',1)
xlabel('x'); ylabel('u');
legend('FE','exact')
title('ne = 4')




