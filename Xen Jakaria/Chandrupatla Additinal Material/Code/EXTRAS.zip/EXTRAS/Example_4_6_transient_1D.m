function [] = Example_4_6_transient_1D()
% see Text, Schmidt, Henderson, Wolgemuth, pg 334
close all; clear all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
global ne nn alp k h le Tinf tau
global t1 uL
alp = 449.1e-9; k = 0.72; h = 50; L = 0.075; Tinf = 15; ne = 8; 
nn = ne+1; 
le = L/ne;
tau = 6*3600;  % 9am-3pm
tspan = [0 tau];
u0 = zeros(1,nn); % initial condition
[t1,u] = ode45(@ode45sub,tspan,u0);
u1 = u(:,1); uL = u(:,nn);
plot(t1/3600,u1,'b')
hold
plot(t1/3600,uL,'b--')
legend('u-CenterLine','u-Surface');
xlabel('time in hours, 9am-3pm'); ylabel('temperature');
title(['ne = ',num2str(ne)])
% temperatures at noon
uCL_noon = interp1(t1,u1,3*3600)
uS_noon = interp1(t1,uL,3*3600)
% heat loss (gain) from 9am-noon, per m^2 of slab area
Q = integral(@fun0,0,tau/2)
sum = 0;
for i=1:ne
  T1 = interp1(t1,u(:,i),3*3600); T2 = interp1(t1,u(:,i+1),3*3600);
  sum = sum + .5*(T1+T2)*le;
end
Taverage = sum/L

function [f] = ode45sub(t,u)
[f] = odefun(t,u);

function [f] = odefun(t,u)
global ne nn alp k h le Tinf tau
me = le/6/alp*[2 1;1 2];
%me = le/2/alp*[1 0;0 1];  % lumped
ke = 1/le*[1 -1;-1 1];
K = zeros(nn); M=zeros(nn);
for n=1:ne
  dof = [n n+1];
  M(dof,dof) = M(dof,dof) + me; K(dof,dof) = K(dof,dof) + ke;
end
K(nn,nn) = K(nn,nn) + h/k;  
F = zeros(nn,1);
F(nn,1) = F(nn,1) + h*Tinf/k;
f = M\(F-K*u);

function ord = fun0(t)
global ne nn alp k h le Tinf
global t1 uL
uLt = interp1(t1,uL,t);
ord = h*(uLt - Tinf);


