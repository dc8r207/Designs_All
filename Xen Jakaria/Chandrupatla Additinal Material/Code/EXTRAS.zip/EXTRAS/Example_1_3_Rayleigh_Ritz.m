function [] = Example_1_3_Rayleigh_Ritz()
clear all; close all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
syms a2 a3 a4 x w L EI
%v = a2*(x/L)^2 + a3*(x/L)^3;
v = a2*(x/L)^2 + a3*(x/L)^3 + a4*(x/L)^4;
vpp = diff(v,x,2);
Ubeam = 0.5*EI*int(vpp^2,x,0,L);
WP = w*int(v,x,0,L);
PE = Ubeam+WP;
eq1 = diff(PE,a2);
eq2 = diff(PE,a3);
eq3 = diff(PE,a4);
%[A,b] = equationsToMatrix([eq1,eq2],[a2,a3])
[A,b] = equationsToMatrix([eq1,eq2,eq3],[a2,a3,a4])
solx = A\b;
% tip_disp = subs(v,[x a2 a3],[L solx(1) solx(2)])
% mid_disp = subs(v,[x a2 a3],[L/2 solx(1) solx(2)])
tip_disp = subs(v,[x a2 a3 a4],[L solx(1) solx(2) solx(3)])
mid_disp = subs(v,[x a2 a3 a4],[L/2 solx(1) solx(2) solx(3)])
