function [] = Example_6_8_traction_8node()
% traction on 8-node quad
clear all; close all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
x2=1; y2=0; x6=1.2; y6=1; x3=0.9; y3=2;
c=1/sqrt(3);
te=1; Tx=1; NIP=2;
eta1(1) = -c; eta1(2) = c; %weight = 1
T2x=0; T6x=0; T3x=0;
for i=1:NIP
eta = eta1(i);
N2 = -.5*(1-eta)*eta;
N2prime = -0.5*(1-2*eta);
N3 = .5*(1+eta)*eta;
N3prime = .5*(1+2*eta);
N6 = 1-eta^2;
N6prime = -2*eta;
J21 = x2*N2prime + x6*N6prime + x3*N3prime;
J22 = y2*N2prime + y6*N6prime + y3*N3prime;
T2x = T2x + N2*Tx*te*sqrt(J21^2+J22^2);
T6x = T6x + N6*Tx*te*sqrt(J21^2+J22^2);
T3x = T3x + N3*Tx*te*sqrt(J21^2+J22^2);
end
T2x, T6x, T3x