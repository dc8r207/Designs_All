function [] = hexa_Matlab_sparse()
clear all;close all;
disp('***************************************');
disp('*       PROGRAM HEXA_MATLAB_SPARSE    *');
disp('* T.R.Chandrupatla and A.D.Belegundu 	*');
disp('***************************************');      
% written by A.D. Belegundu
[nn,ne,x,noc,dof_fixed,E,pnu,F] = InputData();
nen = 8; ndn = 3; ndof=3*nn;
cc= E/(1+pnu)/(1-2*pnu);
D = [1-pnu  pnu pnu 0 0 0;
     pnu 1-pnu pnu 0 0 0;
     pnu pnu 1-pnu 0 0 0;
     0 0 0 .5-pnu 0 0;
     0 0 0 0 .5-pnu 0;
     0 0 0 0 0 .5-pnu];
D = cc*D;
cc = 1/sqrt(3); %wip = 1*1;
xip = cc*[-1 -1 -1;
          1 -1 -1;
          1 1 -1;
          -1 1 -1;
          -1 -1 1;
          1 -1 1;
          1 1 1;
          -1 1 1];
% element loop
iloc=0;
for k = 1:ne
se = zeros(3*nen);
xe = x(noc(k,1:nen),1); ye = x(noc(k,1:nen),2); ze = x(noc(k,1:nen),3);
for IP=1:8
psi = xip(IP,1); eta = xip(IP,2); zeta = xip(IP,3);
N(1)= 0.125*(1-psi)*(1-eta)*(1-zeta); 
dN1_dpsi= -0.125*(1-eta)*(1-zeta); dN1_deta= -0.125*(1-psi)*(1-zeta); dN1_dzeta= -0.125*(1-psi)*(1-eta);
N(2)= 0.125*(1+psi)*(1-eta)*(1-zeta); 
dN2_dpsi= 0.125*(1-eta)*(1-zeta); dN2_deta= -0.125*(1+psi)*(1-zeta); dN2_dzeta= -0.125*(1+psi)*(1-eta);
N(3)= 0.125*(1+psi)*(1+eta)*(1-zeta); 
dN3_dpsi= 0.125*(1+eta)*(1-zeta); dN3_deta= 0.125*(1+psi)*(1-zeta); dN3_dzeta= -0.125*(1+psi)*(1+eta);
N(4)= 0.125*(1-psi)*(1+eta)*(1-zeta); 
dN4_dpsi= -0.125*(1+eta)*(1-zeta); dN4_deta= 0.125*(1-psi)*(1-zeta); dN4_dzeta= -0.125*(1-psi)*(1+eta);
N(5)= 0.125*(1-psi)*(1-eta)*(1+zeta); 
dN5_dpsi= -0.125*(1-eta)*(1+zeta); dN5_deta= -0.125*(1-psi)*(1+zeta); dN5_dzeta= 0.125*(1-psi)*(1-eta);
N(6)= 0.125*(1+psi)*(1-eta)*(1+zeta); 
dN6_dpsi= 0.125*(1-eta)*(1+zeta); dN6_deta= -0.125*(1+psi)*(1+zeta); dN6_dzeta= 0.125*(1+psi)*(1-eta);
N(7)= 0.125*(1+psi)*(1+eta)*(1+zeta); 
dN7_dpsi= 0.125*(1+eta)*(1+zeta); dN7_deta= 0.125*(1+psi)*(1+zeta); dN7_dzeta= 0.125*(1+psi)*(1+eta);
N(8)= 0.125*(1-psi)*(1+eta)*(1+zeta); 
dN8_dpsi= -0.125*(1+eta)*(1+zeta); dN8_deta= 0.125*(1-psi)*(1+zeta); dN8_dzeta= 0.125*(1-psi)*(1+eta);
N = [N(1:8)];
dN_dpsi = [dN1_dpsi dN2_dpsi dN3_dpsi dN4_dpsi dN5_dpsi dN6_dpsi dN7_dpsi dN8_dpsi];
dN_deta = [dN1_deta dN2_deta dN3_deta dN4_deta dN5_deta dN6_deta dN7_deta dN8_deta];
dN_dzeta = [dN1_dzeta dN2_dzeta dN3_dzeta dN4_dzeta dN5_dzeta dN6_dzeta dN7_dzeta dN8_dzeta];
dx_dpsi = dN_dpsi*xe; dy_dpsi = dN_dpsi*ye; dz_dpsi = dN_dpsi*ze;
dx_deta = dN_deta*xe; dy_deta = dN_deta*ye; dz_deta = dN_deta*ze;
dx_dzeta = dN_dzeta*xe; dy_dzeta = dN_dzeta*ye; dz_dzeta = dN_dzeta*ze;
J = [dx_dpsi  dy_dpsi  dz_dpsi;
     dx_deta  dy_deta  dz_deta;
     dx_dzeta dy_dzeta dz_dzeta];
A1 = zeros(6,9);
A1(1,1)=1; A1(2,5)=1; A1(3,9)=1; A1(4,6)=1; A1(4,8)=1; A1(5,3)=1; A1(5,7)=1; A1(6,2)=1; A1(6,4)=1;
Jinv = inv(J); cc = zeros(3);
J1 = [Jinv cc  cc;
      cc  Jinv cc;
      cc  cc   Jinv];
A = A1*J1;
N1 = [N(1) 0 0 N(2) 0 0 N(3) 0 0 N(4) 0 0 N(5) 0 0 N(6) 0 0 N(7) 0 0 N(8) 0 0;
      0 N(1) 0 0 N(2) 0 0 N(3) 0 0 N(4) 0  0 N(5) 0 0 N(6) 0 0 N(7) 0 0 N(8) 0;
      0  0 N(1) 0 0 N(2) 0 0 N(3) 0 0 N(4) 0  0 N(5) 0 0 N(6) 0 0 N(7) 0 0 N(8)];
G = [dN1_dpsi 0 0 dN2_dpsi 0 0 dN3_dpsi 0 0 dN4_dpsi 0 0 dN5_dpsi 0 0 dN6_dpsi 0 0 dN7_dpsi 0 0 dN8_dpsi 0 0;
     dN1_deta 0 0 dN2_deta 0 0 dN3_deta 0 0 dN4_deta 0 0 dN5_deta 0 0 dN6_deta 0 0 dN7_deta 0 0 dN8_deta 0 0;
     dN1_dzeta 0 0 dN2_dzeta 0 0 dN3_dzeta 0 0 dN4_dzeta 0 0 dN5_dzeta 0 0 dN6_dzeta 0 0 dN7_dzeta 0 0 dN8_dzeta 0 0;
     0 dN1_dpsi 0 0 dN2_dpsi 0 0 dN3_dpsi 0 0 dN4_dpsi 0 0 dN5_dpsi 0 0 dN6_dpsi 0 0 dN7_dpsi 0 0 dN8_dpsi 0;
     0 dN1_deta 0 0 dN2_deta 0 0 dN3_deta 0 0 dN4_deta 0 0 dN5_deta 0 0 dN6_deta 0 0 dN7_deta 0 0 dN8_deta 0;
     0 dN1_dzeta 0 0 dN2_dzeta 0 0 dN3_dzeta 0 0 dN4_dzeta 0 0 dN5_dzeta 0 0 dN6_dzeta 0 0 dN7_dzeta 0 0 dN8_dzeta 0;
     0 0 dN1_dpsi 0 0 dN2_dpsi 0 0 dN3_dpsi 0 0 dN4_dpsi 0 0 dN5_dpsi 0 0 dN6_dpsi 0 0 dN7_dpsi 0 0 dN8_dpsi;
     0 0 dN1_deta 0 0 dN2_deta 0 0 dN3_deta 0 0 dN4_deta 0 0 dN5_deta 0 0 dN6_deta 0 0 dN7_deta 0 0 dN8_deta;
     0 0 dN1_dzeta 0 0 dN2_dzeta 0 0 dN3_dzeta 0 0 dN4_dzeta 0 0 dN5_dzeta 0 0 dN6_dzeta 0 0 dN7_dzeta 0 0 dN8_dzeta];
B = A*G;
se = se + B'*D*B*det(J); 
end
% sparse assembly
for i1=1:nen
  for i2=1:ndn
    ic = i2+(i1-1)*ndn; icg = ndn*(noc(k,i1)-1)+i2;
    for j1=1:nen
      for j2=1:ndn
        ir = j2+(j1-1)*ndn; irg = ndn*(noc(k,j1)-1)+j2;
        iloc = iloc+1;
        irs(iloc,1) = irg; ics(iloc,1) = icg; as(iloc,1) = se(ir,ic);
      end
    end
  end
end
end
% enforce BCs
nnz = length(irs)
for m = 1:length(dof_fixed)
  r = dof_fixed(m);
  F(r,1)=0;
  % zero column
  for i=1:nnz
    if ics(i,1) == r
      if irs(i,1)~=r
         as(i,1) = 0;
      end
    end
  end
  % zero row
  for i=1:nnz
    if irs(i,1) == r
      if ics(i,1)~=r
         as(i,1) = 0;
      end
    end
  end
end
KS = sparse(irs,ics,as); 
FS=sparse(F);
U=KS\FS


function [nn,ne,x,noc,dof_fixed,E,pnu,F] = InputData()
nn=20; ne=4;
ndof=3*nn;
dof_fixed =[49:60];
F=zeros(ndof,1); F(12,1)=-80000;
X1= ...
[1     100      0      100;
 2      0       0      100;
 3      0       0      200;
 4     100      0      200;
 5     100     100     100;
 6      0      100     100;
 7      0      100     200;
 8     100     100     200;
 9     100     200     100;
10      0      200     100;
11      0      200     200;
12     100     200     200;
13     100     300     100;
14      0      300     100;
15      0      300     200;
16     100     300     200;
17     100     200      0;
18     100     300      0;
19      0      300      0;
20      0      200      0];
x=X1(1:20,2:4);
noc1= ...
[1     1   2   3   4   5   6   7   8   1      0;
 2     5   6   7   8   9  10  11  12   1      0;
 3     9  10  11  12  13  14  15  16   1      0;
 4     9  10  14  13  17  20  19  18   1      0];
noc = noc1(1:4,2:9);
E=200e3; pnu=0.3;



