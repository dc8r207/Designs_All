function [] = Example10_7_mode_superposition()
clear all; close all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
K = 600*[1 -1  0;
        -1  3 -2;
         0 -2  5];
M = [1  0   0;
     0 1.5  0;
     0  0   2];
[V,D] = eig(K,M);
freq_fea_rad_per_s = sqrt(diag(D)) % rad/s
cc = V'*M*V;
for j=1:3
  alp = 1/sqrt(cc(j,j));
  V(:,j) = V(:,j)*alp;
end
V
F0 = [500 1000 1000]';
pctdamping = [0.02 0.03 0.1];
Fi0 = V'*F0;
tau = 10; dt = 0.01;
tt = linspace(0,tau,tau/dt); Nt = length(tt);
u = zeros(Nt,3);
p = 3;
for i=1:p
  omegan = sqrt(D(i,i)); psi = pctdamping(i); f0 = Fi0(i);
  c_i = 2*omegan*psi; lambda_i = D(i,i);
  omegad = omegan*sqrt(1-psi^2);
  xt = (f0/omegad*exp(-psi*omegan*tt).*sin(omegad*tt))';
  for j=1:3
    u(:,j) = u(:,j) + xt*V(j,i);
  end
end
plot(tt,u(:,2),'k')

