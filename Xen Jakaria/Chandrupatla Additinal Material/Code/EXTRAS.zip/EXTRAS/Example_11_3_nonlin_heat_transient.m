function [] = Example_11_3_nonlin_heat_transient()
close all; clear all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
global ne nn rho_c le k0 beta ND NU U R
% temperature-dependent thermal conductivity:  k(T)= k0(1-beta*T) > 0
% transient heat conduction
L = 0.5; k0 = 400; Q0 = 1e6; Ae = 1;
rho = 9000; sp_heat = 400; rho_c = rho*sp_heat; Tinit = 100; tau = 5000;
beta = .0005;
ne = 5; % no. of elements
nn = ne+1; le = L/ne;
%BCs :
ND=1; NU(1)=nn; U(1)=0;
%--------------------------------------------------------------------------
R = zeros(nn,1);  % 'load' vector
for i=1:ne
  dof = [i i+1];
  rQ = Q0*Ae*le*[.5 .5]';
  R(dof,1) = R(dof,1) + rQ;
end
u0 = Tinit*ones(nn-ND,1); % initial condition
alp0 = k0/rho_c
deltaTcr = le^2/2/alp0
Nt = round(2*tau/deltaTcr);
deltaT = tau/Nt
[t1,y] = ode_FwdEuler(tau,Nt,u0);
i1=round(0.2/le+1); i2=round(0.3/le+1);
% temp. at x=0.2 & x=0.3 (note: x=0 is centerline, x=0.5 is end)
u1 = y(:,i1);
plot(t1,u1,'k')
hold
u2 = y(:,i2);  % temp. at x = 0.3
plot(t1,u2,'k--')
legend('x = 0.2','x = 0.3')
xlabel('time, sec'); ylabel('temp');

function [f] = odefun(t,T)
global ne nn rho_c le k0 beta ND NU U R
me =  rho_c*le/2*[1 0;0 1];  % lumped heat capacity matrix
ke0 = 1/le*[1 -1;-1 1];
K = zeros(nn); M=zeros(nn); F=R;
dof1 = setdiff([1:nn],NU);
T_all = zeros(nn,1); T_all(dof1)=T; T_all(NU)=U;
for n=1:ne
  Tavg = 0.5*(T_all(n)+T_all(n+1));
  tc = k0*(1-beta*Tavg);
  dof = [n n+1];
  ke = tc*ke0;
  M(dof,dof) = M(dof,dof) + me; 
  K(dof,dof) = K(dof,dof) + ke;
end
% BCs
for i=1:nn
  F(i,1)=F(i,1)/M(i,i);
  for j=1:nn
    K(i,j)=K(i,j)/M(i,i);
  end
end
F1=F(dof1,1); K1=K(dof1,dof1);
for i=1:ND
  F1 = F1 - K(dof1,NU(i))*U(i);
end 
f = F1-K1*T;

function [t1,u] = ode_FwdEuler(tau,Nt,u0)
nn0 = length(u0);
t1 = linspace(0,tau,Nt);
deltaT = tau/Nt;
u=zeros(Nt,nn0);
for i=1:nn0
  u_1(i) = u0(i); u(1,i)=u0(i);
end
for n=1:Nt-1
  t = t1(n);
  [f] = odefun(t,u_1');
  for i=1:nn0
    u(n+1,i) = u_1(i) + deltaT*f(i,1);
  end
  u_1 = u(n+1,1:nn0);
end







