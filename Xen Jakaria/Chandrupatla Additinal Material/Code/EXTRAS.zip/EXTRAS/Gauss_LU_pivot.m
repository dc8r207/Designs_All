function [] = Gauss_LU_pivot();
close all;clear all;
disp('***************************************');
disp('*  PROGRAM GAUSS_LU WITH PIVOTING     *');
disp('* T.R.Chandrupatla and A.D.Belegundu 	*');
disp('***************************************'); 

%*****  Gauss Elimination, General Matrix, with LU decomposition *****
%                   (Row pivoting)
% written by A.D. Belegundu, 2021
% Introduction to Finite Elements in Engineering, 5th ed., by
% Chandrupatla/Belegundu
%
% L occupies strict lower triangle in [A] with L(i,i)=1 implicit
% input data
%
iprob = 2
iprint = 1
if (iprob==1)
N = 8;
A = ...
 [6  0  1  2  0  0  2  1
  0  5  1  1  0  0  3  0
  1  1  6  1  2  0  1  2
  2  1  1  7  1  2  1  1
  0  0  2  1  6  0  2  1
  0  0  0  2  0  4  1  0
  2  3  1  1  2  1  5  1
  1  0  2  1  1  0  1  3];
B = ...
 [1  1  1  1  1  1  1  1]';  % column vector
elseif (iprob==2)
N = 3;
A = ...
    [1 -2 6;
     2  2 3;
    -1  3 0];
B = ...
 [1  2  3 ]';  % column vector
end
%
indx = [1:N];
for K = 1:N-1
   cmax = abs(A(K,K)); imax = K; IFL = 0;
   for I = K+1:N
     cc = abs(A(I,K));
     if (cc > cmax)
       cmax = cc; imax = I; IFL = 1;
     end
   end
   if (IFL > 0)
     % swap row K with row imax in A and in rhs B
     cc = indx(K); indx(K) = indx(imax); indx(imax) = cc;  
     cc1 = A(K,1:N); A(K,1:N) = A(imax,1:N); A(imax,1:N) = cc1;
     cc1 = B(K); B(K) = B(imax); B(imax) = cc1;
   end
   for I = K+1:N
      C = A(I, K) / A(K, K); A(I,K) = C;
      for J = K+1:N
         A(I, J) = A(I, J) - C * A(K, J);
      end
   end
end
% forward reduction: L y = b -- note: L(i,i) = 1
for I = 2:N
  for K = 1:I-1
     B(I) = B(I) - A(I,K)*B(K);
  end
end
% back substitution: U x = y
B(N) = B(N) / A(N, N);
for I=2:N
  irow = N-I+1;
  sum = 0;
  for J=irow+1:N
    sum = sum + A(irow,J)*B(J);
  end
  B(irow) = (B(irow)-sum)/A(irow,irow);
end
%
disp(' ')
disp('Solution Vector');
disp(sprintf('%12.4E\n',B'));
%
if iprint == 1
  P=zeros(N);
  for i=1:N
    P(i,indx(i))=1;
  end
  L = tril(A);
  for i=1:N
    L(i,i)=1;
  end
  U = triu(A);
  L,U,P
end


  
