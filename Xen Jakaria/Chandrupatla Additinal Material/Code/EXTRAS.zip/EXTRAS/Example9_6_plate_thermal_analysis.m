function [] = Example9_6_plate_thermal_analysis()
clear all;close all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
global alpha T0
alpha = 11.7e-6; T0=100;
[NN,NE,NQ,NEN,NDN,ND,X,NOC,MAT,F,NU,U,PM] = InputData;
NQ = NDN*NN;
GK=zeros(NQ);
IFL = 0;
for N = 1:NE
  [DBsx,TL,EK] = DKQ_stiffness(IFL, N, MAT, PM, X, NOC);
  i1 = NOC(N,1); i2 = NOC(N,2); i3 = NOC(N,3);
  dof = [3*i1-2 3*i1-1 3*i1 3*i2-2 3*i2-1 3*i2 3*i3-2 3*i3-1 3*i3];
  GK(dof,dof) = GK(dof,dof) + EK;
  F(dof,1) = F(dof,1) + TL;
end
% update force F due to uniform loads
for N=1:NE
  matno = MAT(N);
  UDL = PM(matno,5);
  if abs(UDL)>0
    i1 = NOC(N,1); i2 = NOC(N,2); i3 = NOC(N,3);
    x1=X(i1,1); x2=X(i2,1); x3=X(i3,1); y1=X(i1,2); y2=X(i2,2); y3=X(i3,2);
    dof = [3*i1-2 3*i1-1 3*i1 3*i2-2 3*i2-1 3*i2 3*i3-2 3*i3-1 3*i3];  
    [Fe] = EQV_FORCE(UDL,x1,y1,x2,y2,x3,y3);
    F(dof,1) = F(dof,1) + Fe;
  end
end
%F
% BCs via decoupling technique (Section 3.7, eq. 3.26)
for i=1:ND
  i1 = NU(i);
  for j=1:NQ
    F(j,1)=F(j,1)-GK(j,i1)*U(i);
  end
  F(i1)= GK(i1,i1)*U(i);
  cc = GK(i1,i1);
  for j=1:NQ
    GK(i1,j)=0; GK(j,i1)=0; GK(i1,i1)=cc;
  end
end
Q = GK\F;
Q
IFL = 1;
for N=1:NE
  TH = PM(matno,4);
  [DBsx,EK] = DKQ_stiffness(IFL, N, MAT, PM, X, NOC);
  i1 = NOC(N,1); i2 = NOC(N,2); i3 = NOC(N,3);
  x1=X(i1,1); x2=X(i2,1); x3=X(i3,1); y1=X(i1,2); y2=X(i2,2); y3=X(i3,2);  
  dof = [3*i1-2 3*i1-1 3*i1 3*i2-2 3*i2-1 3*i2 3*i3-2 3*i3-1 3*i3];
  q = Q(dof,1);
  J = [x1-x3 y1-y3;x2-x3 y2-y3];
  Mx(N,:) = TH^3/12*DBsx*q;
end

% comparison with analytical
% Timoshenko & Woinowski_Krieger: pg 164
E=200e9; t = 0.005; a = 1; pnu=0.3;
% node 1
x = 0.5*a; y = 0;
D=E*t^3/12/(1-pnu^2);
K = -alpha*T0*(1+pnu)*4*a^2/pi^3/t;
w = 0;
for m=1:10
  if mod(m,2)~=0
    w = w + K*(sin(m*pi*x/a))/m^3*(1 - cosh(m*pi*y/a)/(cosh(m*pi/2)));
  end
end
w = -w;
disp('pct error at node 1')
abs(w-Q(1))/abs(w)*100
% node 2
x = 0.75*a; y = 0;
D=E*t^3/12/(1-pnu^2);
K = -alpha*T0*(1+pnu)*4*a^2/pi^3/t;
w = 0;
for m=1:10
  if mod(m,2)~=0
    w = w + K*(sin(m*pi*x/a))/m^3*(1 - cosh(m*pi*y/a)/(cosh(m*pi/2)));
  end
end
w = -w;
disp('pct error at node 2')
abs(w-Q(4))/abs(w)*100
% node 5
x = 0.75*a; y = -0.25*a;
D=E*t^3/12/(1-pnu^2);
K = -alpha*T0*(1+pnu)*4*a^2/pi^3/t;
w = 0;
for m=1:10
  if mod(m,2)~=0
    w = w + K*(sin(m*pi*x/a))/m^3*(1 - cosh(m*pi*y/a)/(cosh(m*pi/2)));
  end
end
w = -w;
disp('pct error at node 5')
abs(w-Q(13))/abs(w)*100




function [DBsx,TL,EK] = DKQ_stiffness(IFL, N, MAT, PM, X, NOC)
global alpha T0
matno = MAT(N);
TH = PM(matno,4); E = PM(matno,1); PNU = PM(matno,2); 
C1 = E / (1 - PNU ^ 2);
C2 = C1 * PNU;
C3 = .5 * E / (1 + PNU);     
D = [C1 C2 0.
     C2 C1 0.
     0. 0. C3];
NIP=3;
WT(1:NIP)=1/6;
XNI(1,1)=1/2; XNI(1,2)=1/2; 
XNI(2,1)=0;   XNI(2,2)=1/2;
XNI(3,1)=1/2; XNI(3,2)=0;
EK=zeros(9); fe = zeros(9,1); TL=zeros(9,1);
I1 = NOC(N,1);I2 = NOC(N,2);I3 = NOC(N,3);
T = zeros(6,9);   
for I=1:3
  J1=I;
  J2=I+1;
  if(I==3)
    J2=1;
  end
  XX1=X(NOC(N,J1),1); XX2=X(NOC(N,J2),1);
  YY1=X(NOC(N,J1),2); YY2=X(NOC(N,J2),2);
  L12=sqrt( (XX2-XX1)^2+(YY2-YY1)^2 );
  S1= (XX2-XX1)/L12; S2= (YY2-YY1)/L12;
  T(2*I-1,3*J1-2)=-1.5*S1/L12;
  T(2*I-1,3*J1-1)=-0.75*S1*S2;
  T(2*I-1,3*J1)=.25*S1*S1-.5*S2*S2;
  T(2*I-1,3*J2-2)=1.5*S1/L12;
  T(2*I-1,3*J2-1)=-0.75*S1*S2;
  T(2*I-1,3*J2)=.25*S1*S1-.5*S2*S2;
  T(2*I,3*J1-2)=-1.5*S2/L12;
  T(2*I,3*J1-1)=-.25*S2*S2+.5*S1*S1;
  T(2*I,3*J1)=.75*S1*S2;
  T(2*I,3*J2-2)=1.5*S2/L12;
  T(2*I,3*J2-1)=-.25*S2*S2+.5*S1*S1;
  T(2*I,3*J2)=.75*S1*S2;
end
for IP=1:NIP
  XI = XNI(IP,1); ETA=XNI(IP,2); ZETA=1-XI-ETA;      
  J11=X(I1,1) - X(I3,1); J12=X(I1,2) - X(I3,2); 
  J21=X(I2,1) - X(I3,1); J22=X(I2,2) - X(I3,2);
  DETJ = J11*J22 - J21*J12;
  A(1,1)=J22/DETJ;
  A(1,2)=-J12/DETJ;
  A(1,3)=0.;
  A(1,4)=0.;
  A(2,1)=0.;
  A(2,2)=0.;
  A(2,3)=-J21/DETJ;
  A(2,4)=J11/DETJ;
  A(3,1)=-J21/DETJ;
  A(3,2)=J11/DETJ;
  A(3,3)=J22/DETJ;
  A(3,4)=-J12/DETJ;    
  DS(1,1)=4*XI-1; DS(1,2)=0;
  DS(2,1)=0; DS(2,2)=4*ETA-1;
  DS(3,1)=1-4*ZETA; DS(3,2)=1-4*ZETA;
  DS(4,1)=4*ETA;DS(4,2)=4*XI;
  DS(5,1)=-4*ETA;DS(5,2)=4*(1-XI-2*ETA);
  DS(6,1)=4*(1-2*XI-ETA);DS(6,2)=-4*XI;      
  AA = zeros(4,9);
  for I=1:2
    for J=1:3
      for K=1:9
        AA(I,K)=AA(I,K)+DS(3+J,I)*T(2*J-1,K);
	  end
      AA(I,3*J)=AA(I,3*J)-DS(J,I);
    end
  end    
  for I=1:2
    for J=1:3
      for K=1:9
        AA(2+I,K)=AA(2+I,K)+DS(3+J,I)*T(2*J,K);
      end
      AA(2+I,3*J-1)=AA(2+I,3*J-1)+DS(J,I);
    end
  end      
  BBEND = A*AA;
  DB = D*BBEND;
  EK = EK + TH^3/12*BBEND'*DB*DETJ*WT(IP);
  % assemble temperature load
  TL = TL - alpha*T0*TH^2/12*DB'*[1 1 0]'*DETJ*WT(IP);
end   %end loop NIP

if (IFL == 0)
  DBsx=[]; return
end

% DB at nodes returned for stress calculations
  nen = 3;
  for jj = 1:nen
  if jj==1
    XI=1; ETA=0; ZETA=0;
  elseif jj==2
    XI=0; ETA=1; ZETA=0;
  elseif jj==3
    XI=0; ETA=0; ZETA=1;
  end      
  J11=X(I1,1) - X(I3,1); J12=X(I1,2) - X(I3,2); 
  J21=X(I2,1) - X(I3,1); J22=X(I2,2) - X(I3,2);
  DETJ = J11*J22 - J21*J12;
  A(1,1)=J22/DETJ;
  A(1,2)=-J12/DETJ;
  A(1,3)=0.;
  A(1,4)=0.;
  A(2,1)=0.;
  A(2,2)=0.;
  A(2,3)=-J21/DETJ;
  A(2,4)=J11/DETJ;
  A(3,1)=-J21/DETJ;
  A(3,2)=J11/DETJ;
  A(3,3)=J22/DETJ;
  A(3,4)=-J12/DETJ;    
  DS(1,1)=4*XI-1; DS(1,2)=0;
  DS(2,1)=0; DS(2,2)=4*ETA-1;
  DS(3,1)=1-4*ZETA; DS(3,2)=1-4*ZETA;
  DS(4,1)=4*ETA;DS(4,2)=4*XI;
  DS(5,1)=-4*ETA;DS(5,2)=4*(1-XI-2*ETA);
  DS(6,1)=4*(1-2*XI-ETA);DS(6,2)=-4*XI;      
  AA = zeros(4,9);
  for I=1:2
    for J=1:3
      for K=1:9
        AA(I,K)=AA(I,K)+DS(3+J,I)*T(2*J-1,K);
	  end
      AA(I,3*J)=AA(I,3*J)-DS(J,I);
    end
  end    
  for I=1:2
    for J=1:3
      for K=1:9
        AA(2+I,K)=AA(2+I,K)+DS(3+J,I)*T(2*J,K);
      end
      AA(2+I,3*J-1)=AA(2+I,3*J-1)+DS(J,I);
    end
  end      
  BBEND = A*AA;
  DB = D*BBEND;
  DBsx(jj,:) = DB(1,:);
  end
 


function [f] = EQV_FORCE(UDL,x1,y1,x2,y2,x3,y3)
% q = [w1, dw/dy1, -dw/dx1, w2, ...]'  (9x1)
[Nhat] = GetShapeFn(x1,y1,x2,y2,x3,y3);
J = [x1-x3 y1-y3;x2-x3 y2-y3];
f1 = zeros(9,1);
NIP=3;
WT(1:NIP)=1/6;
XNI(1,1)=1/2; XNI(1,2)=1/2; 
XNI(2,1)=0;   XNI(2,2)=1/2;
XNI(3,1)=1/2; XNI(3,2)=0;
for IP=1:NIP
  xi = XNI(IP,1); eta=XNI(IP,2); zeta=1-xi-eta;
  x = xi*x1 +eta*x2+zeta*x3; y = xi*y1 +eta*y2+zeta*y3;
  cc = [1 x y x^2 y^2 x^3 x^2*y x*y^2 y^3]';
  f1 = f1 + UDL*cc*det(J)*WT(IP);
end
A = inv(Nhat);
f = A'*f1;


function [N] = GetShapeFn(x1,y1,x2,y2,x3,y3)
% w = [1 x y x^2 y^2 x^3 x^2.y x.y^2 y^3]*[a1, a2, ..., a9]'
% order: w,dw/dy,-dw/dx
N(1,:) = [1 x1 y1 x1^2 y1^2 x1^3 x1^2*y1 x1*y1^2 y1^3];
N(2,:) = [0 0 1 0 2*y1 0 x1^2 2*x1*y1 3*y1^2];
N(3,:) = -[0 1 0 2*x1 0 3*x1^2 2*x1*y1 y1^2 0];
N(4,:) = [1 x2 y2 x2^2 y2^2 x2^3 x2^2*y2 x2*y2^2 y2^3];
N(5,:) = [0 0 1 0 2*y2 0 x2^2 2*x2*y2 3*y2^2];
N(6,:) = -[0 1 0 2*x2 0 3*x2^2 2*x2*y2 y2^2 0];
N(7,:) = [1 x3 y3 x3^2 y3^2 x3^3 x3^2*y3 x3*y3^2 y3^3];
N(8,:) = [0 0 1 0 2*y3 0 x3^2 2*x3*y3 3*y3^2];
N(9,:) = -[0 1 0 2*x3 0 3*x3^2 2*x3*y3 y3^2 0];


   %------------------------  function InputData  ---------------------------
function [NN,NE,NQ,NEN,NDN,ND,X,NOC,MAT,F,NU,U,PM] = InputData()
global loadcase
  [NN,   NE,   NM,  NDIM,  NEN,  NDN] = deal(9,    8,    1,    2,    3,    3);
   NQ = 3*NN;
  [ND,   NL,   NMPC] = deal(11 ,   1 ,   0);
 X = ...
    [0.00000e+00     0.00000e+00;
     2.50000e-01     0.00000e+00;
     5.00000e-01     0.00000e+00;
     0.00000e+00     2.50000e-01;
     2.50000e-01     2.50000e-01;
     5.00000e-01     2.50000e-01;
     0.00000e+00     5.00000e-01;
     2.50000e-01     5.00000e-01;
     5.00000e-01     5.00000e-01];
 NOC = ...
     [1       2       5;
      5       4       1;
      2       3       6;
      6       5       2;
      4       5       8;
      8       7       4;
      5       6       9;
      9       8       5];
MAT = ones(1,NE);
NU = [2 5 8 3 12 21 7 16 25 22 19];
U = 0*ones(1,ND);
%       E,    pnu,   rho, thick, UDL
PM = [200e9,  .3,   7800, 0.5e-2 0.0];
F(1:NQ,1)=0;



