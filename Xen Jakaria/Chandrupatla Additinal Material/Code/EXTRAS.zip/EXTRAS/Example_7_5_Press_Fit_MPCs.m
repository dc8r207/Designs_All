function [] = Example_7_5_Press_Fit_MPCs()
clear all;close all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
global Ndivx
% iBC = 1 for master-slave approach, = 0 for penalty function approach
iBC = 1;
[nn,ne,X,noc,mat,dof_spc,dof_slave,dof_master,Es,pnus,Ea,pnua,delta] = InputData();
nen = 4; ndof=2*nn;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cc = 1/sqrt(3); %wip = 1*1;
xip = cc*[-1 -1;
           1 -1 ;
           1  1 ;
          -1  1];
% element loop
S = zeros(ndof); F=zeros(ndof,1);
for k = 1:ne
if mat(k)==1
  E=Es; pnu=pnus;
else
  E=Ea; pnu=pnua;
end
D = E/(1+pnu)/(1-2*pnu)*[1-pnu   pnu   0     pnu;
                         pnu   1-pnu   0     pnu;
                         0       0   0.5-pnu  0;
                         pnu    pnu    0    1-pnu];
xe = X(noc(k,1:nen),1); ye = X(noc(k,1:nen),2);
se = zeros(2*nen);
for IP=1:4
psi = xip(IP,1); eta = xip(IP,2);
N(1)= 0.25*(1-psi)*(1-eta); dN1_dpsi= -0.25*(1-eta); dN1_deta= -0.25*(1-psi);
N(2) = 0.25*(1+psi)*(1-eta); dN2_dpsi= 0.25*(1-eta); dN2_deta= -0.25*(1+psi);
N(3) = 0.25*(1+psi)*(1+eta); dN3_dpsi= 0.25*(1+eta); dN3_deta= 0.25*(1+psi); 
N(4) = 0.25*(1-psi)*(1+eta); dN4_dpsi= -0.25*(1+eta); dN4_deta= 0.25*(1-psi);
N = [N(1) N(2) N(3) N(4)];
dN_dpsi = [dN1_dpsi dN2_dpsi dN3_dpsi dN4_dpsi];
dN_deta = [dN1_deta dN2_deta dN3_deta dN4_deta];
x = N*xe; y = N*ye;
dx_dpsi = dN_dpsi*xe; dy_dpsi = dN_dpsi*ye;
dx_deta = dN_deta*xe; dy_deta = dN_deta*ye;
J = [dx_dpsi dy_dpsi;
     dx_deta dy_deta];
A1 = [1 0 0 0;
      0 0 0 1;
      0 1 1 0];
Jinv = inv(J); cc = zeros(2);
J1 = [Jinv cc;
      cc  Jinv];
A = A1*J1;
N1 = [N(1) 0 N(2) 0 N(3) 0 N(4) 0;
      0 N(1) 0 N(2) 0 N(3) 0 N(4)];
G = [dN1_dpsi 0 dN2_dpsi 0 dN3_dpsi 0 dN4_dpsi 0;
     dN1_deta 0 dN2_deta 0 dN3_deta 0 dN4_deta 0;
     0 dN1_dpsi 0 dN2_dpsi 0 dN3_dpsi 0 dN4_dpsi;
     0 dN1_deta 0 dN2_deta 0 dN3_deta 0 dN4_deta];
B = A*G;
Ba = [B;
     1/x*[N(1) 0 N(2) 0 N(3) 0 N(4) 0]];
se = se + 2*pi*x*Ba'*D*Ba*det(J); 
end
i1=noc(k,1); i2=noc(k,2); i3=noc(k,3); i4=noc(k,4);
dof = [2*i1-1 2*i1 2*i2-1 2*i2 2*i3-1 2*i3 2*i4-1 2*i4];
S(dof,dof) = S(dof,dof) + se;
end
if (iBC == 1)
% SPCs via decoupling technique
nspc = length(dof_spc);
for ii=1:nspc
  i = dof_spc(ii);
  cc = S(i,i);
  S(i,:)=0; S(:,i)=0; S(i,i)=cc;
  F(i,1)=0;
end
% MPCs via master-slave technique
dof_free = setdiff([1:ndof],dof_slave);
nmpc = length(dof_master);
b0 = delta*ones(nmpc,1);
A1 = zeros(ndof);
for i=1:ndof
  [ifl,j] = ismember(i,dof_slave);
  if ifl == 0
    A1(i,i)=1; b(i,1)=0;
  else
    A1(i,dof_master(j))=1; b(i,1) = b0(j,1);
  end
end
A = A1([1:ndof],dof_free);
Sm = A'*S*A; 
Fm = A'*(F-S*b);
Qm = Sm\Fm;
Q=zeros(ndof,1);
Q(dof_free)=Qm;
for i=1:nmpc
  Q(dof_slave(i))=Q(dof_master(i)) + delta;
end
else
%SPCs via penalty function technique
CNST = 1000*max(abs(diag(S)));
for ii=1:length(dof_spc)
  i = dof_spc(ii);
  S(i,i) = S(i,i)+CNST;
end
%MPCs via penalty function technique
nmpc = length(dof_slave);
for ii=1:nmpc
  i2=dof_slave(ii); i1=dof_master(ii);
  delta_S = CNST*[1 -1;-1 1];
  dof = [i1 i2];
  S(dof,dof) = S(dof,dof) + delta_S;
  delta_F = CNST*delta*[-1 1]';
  F(dof,1)=F(dof,1) + delta_F;
end
Q = S\F;
Qpenalty = Q
end
% stresses
for k = 1:ne
if mat(k)==1
  E=Es; pnu=pnus;
else
  E=Ea; pnu=pnua;
end
D = E/(1+pnu)/(1-2*pnu)*[1-pnu   pnu   0     pnu;
                         pnu   1-pnu   0     pnu;
                         0       0   0.5-pnu  0;
                         pnu    pnu    0    1-pnu];
xe = X(noc(k,1:nen),1); ye = X(noc(k,1:nen),2);
se = zeros(2*nen);
for IP=1:4
psi = xip(IP,1); eta = xip(IP,2);
N(1)= 0.25*(1-psi)*(1-eta); dN1_dpsi= -0.25*(1-eta); dN1_deta= -0.25*(1-psi);
N(2) = 0.25*(1+psi)*(1-eta); dN2_dpsi= 0.25*(1-eta); dN2_deta= -0.25*(1+psi);
N(3) = 0.25*(1+psi)*(1+eta); dN3_dpsi= 0.25*(1+eta); dN3_deta= 0.25*(1+psi); 
N(4) = 0.25*(1-psi)*(1+eta); dN4_dpsi= -0.25*(1+eta); dN4_deta= 0.25*(1-psi);
N = [N(1) N(2) N(3) N(4)];
dN_dpsi = [dN1_dpsi dN2_dpsi dN3_dpsi dN4_dpsi];
dN_deta = [dN1_deta dN2_deta dN3_deta dN4_deta];
x = N*xe; y = N*ye;
dx_dpsi = dN_dpsi*xe; dy_dpsi = dN_dpsi*ye;
dx_deta = dN_deta*xe; dy_deta = dN_deta*ye;
J = [dx_dpsi dy_dpsi;
     dx_deta dy_deta];
A1 = [1 0 0 0;
      0 0 0 1;
      0 1 1 0];
Jinv = inv(J); cc = zeros(2);
J1 = [Jinv cc;
      cc  Jinv];
A = A1*J1;
N1 = [N(1) 0 N(2) 0 N(3) 0 N(4) 0;
      0 N(1) 0 N(2) 0 N(3) 0 N(4)];
G = [dN1_dpsi 0 dN2_dpsi 0 dN3_dpsi 0 dN4_dpsi 0;
     dN1_deta 0 dN2_deta 0 dN3_deta 0 dN4_deta 0;
     0 dN1_dpsi 0 dN2_dpsi 0 dN3_dpsi 0 dN4_dpsi;
     0 dN1_deta 0 dN2_deta 0 dN3_deta 0 dN4_deta];
B = A*G;
Ba = [B;
     1/x*[N(1) 0 N(2) 0 N(3) 0 N(4) 0]];
i1=noc(k,1); i2=noc(k,2); i3=noc(k,3); i4=noc(k,4);
dof = [2*i1-1 2*i1 2*i2-1 2*i2 2*i3-1 2*i3 2*i4-1 2*i4];
q = Q(dof,1);
j1 = Ndivx*(Ndivx/2+1); j2 = Ndivx*(Ndivx+1) + Ndivx*Ndivx/2 + 1;
if (k==j1 | k==j2)
% stresses at interface elements
s = D*Ba*q;
k,IP,s
end
end
end

function [nn,ne,X,noc,mat,dof_spc,dof_slave,dof_master,Es,pnus,Ea,pnua,delta] = InputData(iprob)
global Ndivx
Es=200e9; pnus=0.3; Ea=72e9; pnua=0.33; delta=30e-6;
% steel shaft
r0 = 31e-3;
Lx = 2.5e-3; Ly = 39e-3;
Ndivx = 2; Ndivy = Ndivx+1;
ne1 = Ndivx*Ndivy;
nn1 = (Ndivx+1)*(Ndivy+1);
mat(1:ne1) = 1;
%coordinates
for i=1:Ndivy+1    
  for j=1:Ndivx+1
     n=(i-1)*(Ndivx+1)+j;
     x(n,1)=(j-1)*(Lx/Ndivx); x(n,2)=(i-1)*(Ly/Ndivy);
  end
end
x(:,1) = x(:,1)+r0;
X = x;
%connectivity
for i=1:Ndivy
  for j=1:Ndivx
     n=(i-1)*Ndivx+j;
     noc(n,1)=(i-1)*(Ndivx+1)+j; noc(n,2)=noc(n,1)+1; 
     noc(n,3)=noc(n,2)+Ndivx+1; noc(n,4)=noc(n,3)-1;
  end
end
% aluminum sleeve
Lx = (70-33.5)*1e-3; Ly = 39e-3;
%Ndivx = 2; Ndivy = 3;
ne2 = Ndivx*Ndivy;
nn2 = (Ndivx+1)*(Ndivy+1);
mat(ne1+1:ne1+ne2) = 2;
%coordinates
cc = 33.5e-3;
for i=1:Ndivy+1    
  for j=1:Ndivx+1
     n=(i-1)*(Ndivx+1)+j;
     x(nn1+n,1)=(j-1)*(Lx/Ndivx)+cc; x(nn1+n,2)=(i-1)*(Ly/Ndivy);
  end
end
X = x;
%connectivity
for i=1:Ndivy
  for j=1:Ndivx
     n=(i-1)*Ndivx+j;
     noc(ne1+n,1)=(i-1)*(Ndivx+1)+j+nn1; noc(ne1+n,2)=noc(ne1+n,1)+1; 
     noc(ne1+n,3)=noc(ne1+n,2)+Ndivx+1; noc(ne1+n,4)=noc(ne1+n,3)-1;
  end
end
ne = ne1+ne2; nn = nn1+nn2;
for j=1:Ndivy+1
  i1 = (Ndivx+1)*j;
  dof_master(j) = 2*i1-1;
  i2 = nn1 + 1+(Ndivx+1)*(j-1);
  dof_slave(j) = 2*i2-1;
end
%dof_spc = [2 4 6 26 28 30];
for i=1:Ndivx+1
  dof_spc(i) = 2*i;
  dof_spc(Ndivx+1+i) = 2*(nn1+i);
end




















