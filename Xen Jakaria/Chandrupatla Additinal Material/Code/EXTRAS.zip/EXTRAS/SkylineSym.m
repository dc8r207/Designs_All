function []=Column_skyline_solver()
close all;clear all;
disp('***************************************');
disp('*          PROGRAM SKYLINE             *');
disp('* T.R.Chandrupatla and A.D.Belegundu 	*');
disp('***************************************'); 

% input data
%
N = 8;
% [A] is symmetric and stored in skyline format --> AN()
AN = [10 13 9 8 7 7 -2 0 0 5 9 3 0 0 13 -1 -1 0 2 19 0  0 .2 0 11 -1.5 -4];
IA = [1 3 4 6 11 16 19 27];
B = [1 2 3 -4 5 6 7 8]';
profile = IA(N)-N
%
for icol = 2:N
  n1 = IA(icol)-IA(icol-1)-1;
  for k=1:icol-1
    if k>=icol-n1
      i1 = IA(icol)-(icol-k);
      C = AN(i1)/AN(IA(k));
      for irow = k+1:icol
        n2 = IA(irow)-IA(irow-1)-1;
        if k>= irow-n2
          i1 = IA(icol)-(icol-irow); i2 = IA(irow)-(irow-k);
          AN(i1) = AN(i1)-C*AN(i2);
        end
      end
    end
  end
end
% forward reduction
for k=1:N-1
  C = B(k)/AN(IA(k));
  for irow = k+1:N
    n2 = IA(irow)-IA(irow-1)-1;
    if k>= irow-n2
      i2 = IA(irow)-(irow-k);
      B(irow) = B(irow) - C*AN(i2);
    end
  end
end
% back substitution: U x = y
B(N) = B(N)/AN(IA(N));
for I=2:N
  irow = N-I+1;
  sum = 0;
  for J=irow+1:N
    n2 = IA(J)-IA(J-1)-1;
    if irow >= J-n2
      i2 = IA(J)-(J-irow);
      sum = sum + AN(i2)*B(J);
    end
  end
  B(irow) = (B(irow)-sum)/AN(IA(irow));
end
%
disp(' ')
disp('Solution Vector');
disp(sprintf('%12.4E\n',B'));

