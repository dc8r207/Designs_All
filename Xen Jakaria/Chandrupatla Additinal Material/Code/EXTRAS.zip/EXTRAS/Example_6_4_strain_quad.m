function [] = Example_6_4_strain_quad()
clear all;close all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
psi = 1/3; eta= 1/3;
N(1)= 0.25*(1-psi)*(1-eta); dN1_dpsi= -0.25*(1-eta); dN1_deta= -0.25*(1-psi);
N(2) = 0.25*(1+psi)*(1-eta); dN2_dpsi= 0.25*(1-eta); dN2_deta= -0.25*(1+psi);
N(3) = 0.25*(1+psi)*(1+eta); dN3_dpsi= 0.25*(1+eta); dN3_deta= 0.25*(1+psi); 
N(4) = 0.25*(1-psi)*(1+eta); dN4_dpsi= -0.25*(1+eta); dN4_deta= 0.25*(1-psi);
N = [N(1) N(2) N(3) N(4)];
dN_dpsi = [dN1_dpsi dN2_dpsi dN3_dpsi dN4_dpsi];
dN_deta = [dN1_deta dN2_deta dN3_deta dN4_deta];
x1=3;x2=3;x3=0;x4=0;
y1=0; y2=2; y3=2; y4=0;
xe = [x1 x2 x3 x4]'; ye = [y1 y2 y3 y4]';
x = N*xe; y = N*ye;
dx_dpsi = dN_dpsi*xe; dy_dpsi = dN_dpsi*ye;
dx_deta = dN_deta*xe; dy_deta = dN_deta*ye;
J = [dx_dpsi dy_dpsi;
     dx_deta dy_deta];
A1 = [1 0 0 0;
      0 0 0 1;
      0 1 1 0];
Jinv = inv(J); cc = zeros(2);
J1 = [Jinv cc;
      cc  Jinv];
A = A1*J1;
N1 = [N(1) 0 N(2) 0 N(3) 0 N(4) 0;
      0 N(1) 0 N(2) 0 N(3) 0 N(4)];
G = [dN1_dpsi 0 dN2_dpsi 0 dN3_dpsi 0 dN4_dpsi 0;
     dN1_deta 0 dN2_deta 0 dN3_deta 0 dN4_deta 0;
     0 dN1_dpsi 0 dN2_dpsi 0 dN3_dpsi 0 dN4_dpsi;
     0 dN1_deta 0 dN2_deta 0 dN3_deta 0 dN4_deta];
B = A*G;
q = 1e-5*[1.913, 0, 0.875, -7.436, 0, 0, 0, 0]';
e = B*q