function [] = Example_8_3_transient_heat_cylinder()
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
close all; clear all;
global ne nn alp k ho L le Tinfo x
global t1 uouter
%
k = 17.08; Tinfo = 180; ho = 50;
alp = 4.15e-6;
ne = 8; % no. of finite elements
nn = ne+1; %no. of nodes
ne
ri = 0; ro = 0.1;
L = ro-ri;
x = [ri:L/ne:ro];
%
tau = 100*60;
tspan = [0 tau];
u0 = 600*ones(nn,1);
[t1,y] = ode45(@odefun,tspan,u0);
ui = y(:,1); uouter = y(:,nn);
plot(t1/60,ui,'b')
hold on
plot(t1/60,uouter,'b--');
legend('u-inner','u-outer');
t0 = 45*60;
ui_45min = interp1(t1,ui,t0);
disp(' ')
disp(sprintf('inner temp at 45min = %15.4E\n', ui_45min));
plot(t0/60,ui_45min,'--gs','MarkerSize',10,'MarkerEdgeColor','b',...
                                 'MarkerFaceColor',[0.5,0.5,0.5]);
% heat loss during 45 minutes of cooling
Qout = 1e-3*integral(@fun0,0,t0);
disp(sprintf('heat out in kJ = %15.4E\n', Qout));

function ord = fun0(t)
global ne nn alp k ho L le Tinfo x
global t1 uouter
uot = interp1(t1,uouter,t);
ro = x(nn);
ord = 2*pi*ro*ho*(uot - Tinfo);

function [f] = odefun(t,y)
global ne nn alp k ho L le Tinfo x
% assembly
psi(1)= -1/sqrt(3); psi(2)= 1/sqrt(3);
M = zeros(nn); K=zeros(nn);
for n=1:ne
  me = zeros(2); ke = zeros(2);
  r1 = x(n); r2=x(n+1); le = abs(r2-r1);
  for IP=1:2
    N1 = (1-psi(IP))/2; N2 = (1+psi(IP))/2;
    B = [-1 1]/le;
    N = [N1 N2];
    me = me + le/2*N'*N*(N1*r1 + N2*r2);
    ke = ke + le/2*B'*B*(N1*r1 + N2*r2);
  end
  % assembly
  dof = [n n+1];
  M(dof,dof) = M(dof,dof) + me; K(dof,dof) = K(dof,dof) + ke;
end
M = 1/alp*M;
% BCs
ro = x(nn);
K(nn,nn) = K(nn,nn) + ro*ho/k;  
%
F = zeros(nn,1);
F(nn,1) = F(nn,1) + ro*ho*Tinfo/k*heaviside(t);
f = M\(F-K*y);

