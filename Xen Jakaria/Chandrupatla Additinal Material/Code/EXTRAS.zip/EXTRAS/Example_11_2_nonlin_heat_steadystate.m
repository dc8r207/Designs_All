function [] = Example_11_2_nonlin_heat_steadystate()
close all; clear all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
% temperature-dependent thermal conductivity:  k(T)= k0(1-beta*T) > 0
L = 0.5; k0 = 400; Q0 = 1e6; Ae = 1;
beta = .0005;
tol = 1; % percentage tolerance
ne = 5; % no. of elements
nn = ne+1; le = L/ne;
load_incs = 5;  % no. of load increments
itermax = 10;  % iterations per load step
lambda = 1/load_incs; 
%BCs :
ND=1; NU(1)=nn; U(1)=0;
%--------------------------------------------------------------------------
F = zeros(nn,1);  % 'load' vector
for i=1:ne
  dof = [i i+1];
  rQ = Q0*Ae*le*[.5 .5]';
  F(dof,1) = F(dof,1) + rQ;
end
TR = F;
T = zeros(nn,1); T(NU)=U; % starting guess
for ITERLOAD = 1:load_incs
  F = ITERLOAD*lambda*TR;
  for ITER = 1:itermax         
    [J,R] = Jacob_Resid(ne,nn,k0,beta,le,T,F); %Jacobian, Residual
    % BC T(node) = Ts --> delta_T(node) = 0
    dof = setdiff([1:nn],NU);
    J1 = J(dof,dof); R1 = R(dof,1);
    delta_T = J1\R1;
    T(dof,1) = T(dof,1) + delta_T;
    perr = norm(delta_T,2)/(norm(T(dof,1),2)+1e-12)*100;
    if perr>tol && ITER==itermax
      disp('pct error > tol')
      ITERLOAD, perr
      return
    elseif perr<=tol
      break
    end
  end    
end
T
xc = linspace(0,L,nn);
plot(xc,T,'k');
xlabel('x-coordinate'); ylabel('temp'); xticks(xc);
legend(strcat('beta =', num2str(beta)));


function [J,R] = Jacob_Resid(ne,nn,k0,beta,le,T,F)
J = zeros(nn); R = F;
for n=1:ne
  Tavg = 0.5*(T(n)+T(n+1));
  tc = k0*(1-beta*Tavg);
  d_tc = -k0*beta*0.5;
  ke = tc/le*[1 -1;-1 1];
  dof = [n n+1];
  J(dof,dof) = J(dof,dof) + ke;
  J(dof,dof) = J(dof,dof) + d_tc/le*[T(n)-T(n+1),-T(n)+T(n+1)]'*[1 1];
  R(dof,1) = R(dof,1) - ke*[T(n) T(n+1)]';
end










