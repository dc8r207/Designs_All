function [] = Example_6_9_quad_analysis_sparse()
clear all;close all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
nen = 4; ndn = 2;
iplot = 0
% rectangular region meshing
Lx = 6; Ly = 1; 
P = -10;
Ndivx = 6*4*4; Ndivy = 2*4*4;

ne = Ndivx*Ndivy
nn = (Ndivx+1)*(Ndivy+1)
ndof = 2*nn;
%coordinates
for i=1:Ndivy+1    
  for j=1:Ndivx+1
     n=(i-1)*(Ndivx+1)+j;
     x(n,1)=(j-1)*(Lx/Ndivx); x(n,2)=(i-1)*(Ly/Ndivy);
  end
end
%connectivity
for i=1:Ndivy
  for j=1:Ndivx
     n=(i-1)*Ndivx+j;
     noc(n,1)=(i-1)*(Ndivx+1)+j; noc(n,2)=noc(n,1)+1; 
     noc(n,3)=noc(n,2)+Ndivx+1; noc(n,4)=noc(n,3)-1;
  end
end
%
if (iplot==1)
  axis off;
  for N=1 : ne
    for j=1 : nen
      xe1(j)=x(noc(N,j),1);
      ye1(j)=x(noc(N,j),2);
    end
    xe1(j+1)=xe1(1);ye1(j+1)=ye1(1);
    line(xe1,ye1)
  end
  LX = abs(max(x(:,1))-min(x(:,1)));
  LY = abs(max(x(:,2))-min(x(:,2)));
  LMAX = max (LX,LY);
  epsilon = 0.01*LMAX;
  for i=1:nn
     xc = x(i,1)-epsilon; yc=x(i,2)-epsilon;
     hh1(i,:)=text(xc,yc,num2str(i),'FontSize',8);
  end 
end
%
%material
E = 200e3; pnu=0.25;
D = E/(1-pnu^2)*[1 pnu 0;pnu 1 0;0 0 0.5*(1-pnu)];
% thickness
t = 0.5;
% BCs
k=0;
for j=1:Ndivy+1
  i1 = 1 + (Ndivx+1)*(j-1);
  k=k+1; dof_fixed(k)=2*i1-1; 
  k=k+1; dof_fixed(k)=2*i1;
end
% load
F = zeros(ndof,1); 
F(2*nn) = -10;
cc = 1/sqrt(3); %wip = 1*1;
xip(1,1)=-cc; xip(1,2)=-cc; xip(2,1)=cc; xip(2,2)=-cc;
xip(3,1)=cc; xip(3,2)=cc; xip(4,1)=-cc; xip(4,2)=cc;
%%%%%%%%  assembly %%%%%%%%%%
iloc=0;
for k = 1:ne
se = zeros(2*nen);
xe = x(noc(k,1:nen),1); ye = x(noc(k,1:nen),2);
for IP=1:4
psi = xip(IP,1); eta = xip(IP,2);
N(1)= 0.25*(1-psi)*(1-eta); dN1_dpsi= -0.25*(1-eta); dN1_deta= -0.25*(1-psi);
N(2) = 0.25*(1+psi)*(1-eta); dN2_dpsi= 0.25*(1-eta); dN2_deta= -0.25*(1+psi);
N(3) = 0.25*(1+psi)*(1+eta); dN3_dpsi= 0.25*(1+eta); dN3_deta= 0.25*(1+psi); 
N(4) = 0.25*(1-psi)*(1+eta); dN4_dpsi= -0.25*(1+eta); dN4_deta= 0.25*(1-psi);
N = [N(1) N(2) N(3) N(4)];
dN_dpsi = [dN1_dpsi dN2_dpsi dN3_dpsi dN4_dpsi];
dN_deta = [dN1_deta dN2_deta dN3_deta dN4_deta];
dx_dpsi = dN_dpsi*xe; dy_dpsi = dN_dpsi*ye;
dx_deta = dN_deta*xe; dy_deta = dN_deta*ye;
J = [dx_dpsi dy_dpsi;
     dx_deta dy_deta];
A1 = [1 0 0 0;
      0 0 0 1;
      0 1 1 0];
Jinv = inv(J); cc = zeros(2);
J1 = [Jinv cc;
      cc  Jinv];
A = A1*J1;
N1 = [N(1) 0 N(2) 0 N(3) 0 N(4) 0;
      0 N(1) 0 N(2) 0 N(3) 0 N(4)];
G = [dN1_dpsi 0 dN2_dpsi 0 dN3_dpsi 0 dN4_dpsi 0;
     dN1_deta 0 dN2_deta 0 dN3_deta 0 dN4_deta 0;
     0 dN1_dpsi 0 dN2_dpsi 0 dN3_dpsi 0 dN4_dpsi;
     0 dN1_deta 0 dN2_deta 0 dN3_deta 0 dN4_deta];
B = A*G;
se = se + t*B'*D*B*det(J); 
end
% sparse assembly
for i1=1:nen
  for i2=1:ndn
    ic = i2+(i1-1)*ndn; icg = ndn*(noc(k,i1)-1)+i2;
    for j1=1:nen
      for j2=1:ndn
        ir = j2+(j1-1)*ndn; irg = ndn*(noc(k,j1)-1)+j2;
        iloc = iloc+1;
        irs(iloc,1) = irg; ics(iloc,1) = icg; as(iloc,1) = se(ir,ic);
      end
    end
  end
end
end
nnz = length(irs)
for m = 1:length(dof_fixed)
  r = dof_fixed(m);
  F(r,1)=0;
  % zero column
  for i=1:nnz
    if ics(i,1) == r
      if irs(i,1)~=r
         as(i,1) = 0;
      end
    end
  end
  % zero row
  for i=1:nnz
    if irs(i,1) == r
      if ics(i,1)~=r
         as(i,1) = 0;
      end
    end
  end
end
KS = sparse(irs,ics,as); 
FS=sparse(F);
t1=cputime;
U=KS\FS;
Ndivx,Ndivy
tip_delta_y = U(2*(Ndivx+1))
t2=cputime;
disp(sprintf('time = %15.4E \n',t2-t1));

