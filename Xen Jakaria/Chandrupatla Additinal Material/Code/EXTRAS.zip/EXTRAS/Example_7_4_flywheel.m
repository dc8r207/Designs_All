function [] = Example_7_4_flywheel()
clear all;close all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
% Example 6.4  flywheel - note: body force assembled in element-loop
[nn,ne,X,noc,dof_spc,E,pnu] = InputData();
nen = 3; ndof=2*nn;
nip = 1; wip(1) = 0.5; xip = [1/3 1/3];
% element loop
S = zeros(ndof); F=zeros(ndof,1);
for k = 1:ne
  [D] = D_matrix(E,pnu);    
  re = X(noc(k,1:nen),1); ze = X(noc(k,1:nen),2);
  se = zeros(2*nen); fe = zeros(2*nen,1);
  for IP=1:nip
    psi = xip(IP,1); eta = xip(IP,2);
    IFL = 1;
    [x, J, Ba, delta_fe] = Strain_Displacement_matrix(IFL,psi,eta,re,ze);
    r = x;
    se = se + wip(IP)*2*pi*r*Ba'*D*Ba*det(J); 
    fe = fe +  wip(IP)*delta_fe;
  end
  i1=noc(k,1); i2=noc(k,2); i3=noc(k,3);
  dof = [2*i1-1 2*i1 2*i2-1 2*i2 2*i3-1 2*i3];
  S(dof,dof) = S(dof,dof) + se;
  F(dof,1) = F(dof,1) + fe;
end
% SPCs
nspc = length(dof_spc);
for ii=1:nspc
  i = dof_spc(ii);
  cc = S(i,i);
  S(i,:)=0; S(:,i)=0; S(i,i)=cc;
  F(i,1)=0;
end
Q = S\F;
F
% stresses
for k = 1:ne
  [D] = D_matrix(E,pnu);
  re = X(noc(k,1:nen),1); ze = X(noc(k,1:nen),2);
  se = zeros(2*nen);
  for IP=1:nip
    psi = xip(IP,1); eta = xip(IP,2);
    IFL=0;
    [x, J, Ba, delta_fe] = Strain_Displacement_matrix(IFL,psi,eta,re,ze);
    r = x;
    i1=noc(k,1); i2=noc(k,2); i3=noc(k,3);
    dof = [2*i1-1 2*i1 2*i2-1 2*i2 2*i3-1 2*i3];
    q = Q(dof,1);
    s = D*Ba*q;
    k,IP,s
  end
end

function [x, J, Ba, delta_fe] = Strain_Displacement_matrix(IFL,psi,eta,xe,ye)
N(1)= psi; dN1_dpsi= 1; dN1_deta= 0;
N(2) = eta; dN2_dpsi= 0; dN2_deta= 1;
N(3) = 1-psi-eta; dN3_dpsi= -1; dN3_deta= -1; 
N = [N(1) N(2) N(3)];
dN_dpsi = [dN1_dpsi dN2_dpsi dN3_dpsi];
dN_deta = [dN1_deta dN2_deta dN3_deta];
x = N*xe; y = N*ye;
dx_dpsi = dN_dpsi*xe; dy_dpsi = dN_dpsi*ye;
dx_deta = dN_deta*xe; dy_deta = dN_deta*ye;
J = [dx_dpsi dy_dpsi;
     dx_deta dy_deta];
A1 = [1 0 0 0;
      0 0 0 1;
      0 1 1 0];
Jinv = inv(J); cc = zeros(2);
J1 = [Jinv cc;
      cc  Jinv];
A = A1*J1;
N1 = [N(1) 0 N(2) 0 N(3) 0;
      0 N(1) 0 N(2) 0 N(3)];
G = [dN1_dpsi 0 dN2_dpsi 0 dN3_dpsi 0;
     dN1_deta 0 dN2_deta 0 dN3_deta 0;
     0 dN1_dpsi 0 dN2_dpsi 0 dN3_dpsi;
     0 dN1_deta 0 dN2_deta 0 dN3_deta];
B = A*G;
Ba = [B;
     1/x*[N(1) 0 N(2) 0 N(3) 0]];
if IFL==1
  % load at integration point
  fr = 0.283/(32.2*12)*x*(3000*2*pi/60)^2; fz=0;
  delta_fe = 2*pi*N1'*[fr fz]'*x*det(J);
else
  delta_fe = [];
end

function [D] = D_matrix(E,pnu)
  D = E/(1+pnu)/(1-2*pnu)*[1-pnu   pnu   0     pnu;
                         pnu   1-pnu   0     pnu;
                         0       0   0.5-pnu  0;
                         pnu    pnu    0    1-pnu];

                     
function [nn,ne,X,noc,dof_spc,E,pnu] = InputData()
E=30e6; pnu=0.3;
nn=6; ne=4; dof_spc = [2 6 10];
X= [3  0; 3  0.5; 7.5  0; 7.5  0.5; 12  0; 12  0.5];
noc = [1 3 2; 2 3 4; 4 3 5; 5 6 4];













