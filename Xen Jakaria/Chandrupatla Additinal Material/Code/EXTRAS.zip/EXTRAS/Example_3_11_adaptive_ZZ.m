function [] = Example3_11_adaptive_ZZ()
clear all;close all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
L = 42; E=1e7; A=0.6;
rhow = 0.2836; om = 30;
%threshold
etabar = 0.3  

ne = 4  % initial
X = linspace(0,L,ne+1);

% %final
% ne = 7
% X = [0, 13, 20.5, 26, 31, 36, 40, 42];


fac = ones(1,ne);  % store adaptivity info per element
for iter = 1:1
maxfac = max(fac);
if iter>1 && maxfac == 1
  iter,ne
  break
end
Y = [];
for j=1:ne
  y = linspace(X(j),X(j+1),fac(j)+1);
  Y=union(Y,y);
end
X = Y;
nn = length(X);
ne = nn-1;
fac = ones(1,ne);
%
F = zeros(nn,1);
for i=1:ne
  x1 = X(i); x2=X(i+1);
  Le = abs(x2-x1);
  fx = rhow/(32.2*12)*om^2;
  fe = fx*A*Le*[(2*X(i)+X(i+1))/6  (X(i)+2*X(i+1))/6];
  F(i,1) = F(i,1)+fe(1); F(i+1,1) = F(i+1,1)+fe(2); 
end
K = zeros(nn);
for i=1:ne
  x1 = X(i); x2=X(i+1);
  Le = abs(x2-x1); 
  k = E*A/Le*[1 -1;-1 1];
  dof = [i i+1];
  K(dof,dof) = K(dof,dof) + k;
end
K1 = K(2:nn,2:nn); F1=F(2:nn,1);
Q1=K1\F1;
Q=[0 Q1']';
for i=1:ne
  x1 = X(i); x2=X(i+1);
  Le = abs(x2-x1);
  q = [Q(i) Q(i+1)]';  
  FE_strain = (q(2)-q(1))/Le;
  FE_stress(i) = E*FE_strain;
end
FE_stress
% >>>>>> plot stresses
figure(iter)
hold
for i=1:ne
  x1 = X(i); x2=X(i+1);
  LH(1)=plot ([x1 x2],[FE_stress(i) FE_stress(i)],'k','linewidth',1.5);
  if (i>1)
    plot([x1 x1],[FE_stress(i-1) FE_stress(i)],'k--','linewidth',0.05)
  end
end
M = zeros(nn); R=zeros(nn,1);
% obtain nodal stresses
for i=1:ne
  x1 = X(i); x2=X(i+1);
  Le = abs(x2-x1);
  dof = [i i+1];
  m = Le/2*[1 0;0 1];
  M(dof,dof) = M(dof,dof) + m;
  r = Le*FE_stress(i)/2*[1 1]';
  R(dof,1) = R(dof,1) + r;
end
SN = M\R;
denom = 0;
for i=1:ne
  x1 = X(i); x2=X(i+1);
  Le = abs(x2-x1);
  LH(2)=plot([x1 x2],[SN(i) SN(i+1)],'k-o');
  a1 =(SN(i+1)-SN(i))/Le; b1 = SN(i)-(SN(i+1)-SN(i))/Le*x1-FE_stress(i);
  e_sigma(i,1) = a1^2/3*(x2^3-x1^3) + b1^2*Le + 2*a1*b1/2*(x2^2-x1^2);
  denom = denom + e_sigma(i,1);
end
%denom = denom/ne;
legend(LH,'\sigma_e','\sigma_{best-fitted}')
xlabel('x');
ylabel('stress');
for i=1:ne
  eta(i) = sqrt(e_sigma(i,1)/denom);
end
e_sigma,denom,eta
for i=1:ne
  psi = eta(i)/etabar;
  fac(i) = psi;
end
fac
for i=1:ne
  elength(i)=abs(X(i+1)-X(i));
end
elength
SN
end













