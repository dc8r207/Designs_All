function [] = Example9_2_beam_analysis()
clear all; close all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
ne = 2; nn=3;
nq = 2*nn;
X = [0 1 2];
noc = [1 2;
       2 3];
E = 200e9; I=4e-6;
F = [0 0 -6000 -1000 -6000 1000]';
ND = 4;
NU = [1 2 3 5]; U(1:ND)=0;
UDL(1) = 0; UDL(2) = -12000;
% stiffness assembly
K = zeros(nq);
for i=1:ne
  i1 = noc(i,1); i2 = noc(i,2);
  x1 = X(i1); x2=X(i2);
  Le = abs(x2-x1);
  k = E*I/Le^3*[12    6*Le   -12   6*Le;
                6*Le  4*Le^2 -6*Le 2*Le^2;
                -12  -6*Le    12   -6*Le;
                6*Le  2*Le^2 -6*Le 4*Le^2];
  dof = [2*i1-1 2*i1 2*i2-1 2*i2];
  K(dof,dof) = K(dof,dof) + k;
end
% BCs via decoupling technique (Section 3.7, eq. 3.26)
for i=1:ND
  i1 = NU(i);
  for j=1:nq
    F(j,1)=F(j,1)-K(j,i1)*U(i);
  end
  F(i1)= K(i1,i1)*U(i);
  cc = K(i1,i1);
  for j=1:nq
    K(i1,j)=0; K(j,i1)=0; K(i1,i1)=cc;
  end
end
Q = K\F
% deflection at mid-point of element 2
x1= 1; x2= 2;
q = [Q(3,1) Q(4,1) Q(5,1) Q(6,1)]';
psi = 0;
le = abs(x2-x1);
H1= .25*(1-psi).^2 .*(2+psi); H2= .25*(1-psi).^2 .*(psi+1);
H3= .25*(1+psi).^2 .*(2-psi); H4= .25*(1+psi).^2 .*(psi-1);
v = H1*q(1) + le/2*H2*q(2) + H3*q(3) + le/2*H4*q(4)
% Bending Moment Diagram
hold
for i=1:ne
  i1 = noc(i,1); i2 = noc(i,2);
  dof = [2*i1-1 2*i1 2*i2-1 2*i2]; 
  q = Q(dof,1);
  x1 = X(i1); x2=X(i2);
  Le = abs(x2-x1);
  k = E*I/Le^3*[12    6*Le   -12   6*Le;
                6*Le  4*Le^2 -6*Le 2*Le^2;
                -12  -6*Le    12   -6*Le;
                6*Le  2*Le^2 -6*Le 4*Le^2];
   p = UDL(i);
   fer = [-p*Le/2 -p*Le^2/12 -p*Le/2 p*Le^2/12]';
   R = k*q + fer;     % eq. (9.23)
   BM(i,1)= -R(2); BM(i,2)= R(4);
   plot([x1 x2],[BM(i,1) BM(i,2)],'k');
end
legend('Bending Moment Diagram')
BM








