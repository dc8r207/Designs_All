function [] = Example5_3_truss()
clear all;close all;
disp('*******************************************');
disp('*   T.R.Chandrupatla and A.D.Belegundu 	*');
disp('* INTRO FINITE ELEMENTS IN ENGRG. 5TH ED. *');
disp('*******************************************'); 
% written by A.D. Belegundu
ne = 4; nn=4;
X = [0 0;
    40 0;
    40 30;
    0  30];
noc = [1 2;
       3 2;
       1 3;
       4 3];
E = 29.5e6*ones(1,ne);
A = 1.0*ones(1,ne);
F = [0 0 20000 0 0 -25000 0 0]'; % externally applied loads
K = zeros(2*nn);
% stiffness assembly
for i=1:ne
  i1 = noc(i,1); i2 = noc(i,2);
  x1 = X(i1,1); x2=X(i2,1); y1 = X(i1,2); y2=X(i2,2);
  Le = sqrt((x2-x1)^2+(y2-y1)^2);
  el = (x2-x1)/Le; em = (y2-y1)/Le;
  L = [el em 0 0;
       0  0  el em];
  klocal = E(i)*A(i)/Le*[1 -1;
                    -1 1];
  k = L'*klocal*L;
  dof = [2*i1-1 2*i1 2*i2-1 2*i2];
  K(dof,dof) = K(dof,dof) + k;
end
% BCs via elimination technique -- fixed dofs are 1,2,4,7,8
dof_free = [3 5 6];
Kr = K(dof_free,dof_free); Fr = F(dof_free);
Qr = Kr\Fr; % or Qr = inv(Kr)*Fr
Q = [0 0 Qr(1) 0 Qr(2) Qr(3) 0 0]';
Q
% stresses
for i=1:ne
  i1 = noc(i,1); i2 = noc(i,2);
  x1 = X(i1,1); x2=X(i2,1); y1 = X(i1,2); y2=X(i2,2);
  Le = sqrt((x2-x1)^2+(y2-y1)^2);
  el = (x2-x1)/Le; em = (y2-y1)/Le;
  L = [-el -em  el em];
  dof = [2*i1-1 2*i1 2*i2-1 2*i2]; 
  q = [Q(dof)];
  s(i) = E(i)/Le*L*q;
end
s
% Reaction forces
R = K*Q-F;
dof_support = [1 2 4 7 8]; R(dof_support)