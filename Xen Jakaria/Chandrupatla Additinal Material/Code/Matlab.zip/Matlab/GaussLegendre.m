function []=GaussLegendre();
close all;
clear all;
%   ***** GAUSS - LEGENDRE INTEGRATION POINTS AND WEIGHTS *****
%   *           T.R.CHANDRUPATLA AND A.D.BELEGUNDU            *
%   *                        2020                             *
%   ***********************************************************
      prompt = 'Number of Integration Points? ';
      n = input(prompt);
      n1 = floor((n + 1) / 2);
      disp('#  Point x (+-)    Weight')
      for j = 1: n1
%     ----- integraion points/weights evaluation
         x = cos(pi() * (j - 0.25) / (n + 0.5));
         while 1
            p1 = 0;
            p2 = 1;
            for i = 1:n
               p3 = (2 - 1 / i) * x * p2 - (1 - 1 / i) * p1;
               p1 = p2;
               p2 = p3;
            end
            dp = n / (x^2 - 1) * (x * p2 - p1);
            x = x - p2 / dp;
            if abs(p3) < 0.00000001
                break;
            end
         end
         w = 2 / (1 - x^2) / dp^2;
         fprintf('%d  %.8f  %.8f \n',j, x, w);
      end

   end
