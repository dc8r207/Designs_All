function [] = Gauss_sym_banded();
close all;clear all;
disp('***************************************');
disp('*    PROGRAM GAUSS_SYM_BANDED          *');
disp('* T.R.Chandrupatla and A.D.Belegundu 	*');
disp('***************************************'); 


%*****  Gauss Elimination Method (Symmetric, Banded Matrix) *****
%                   (no pivoting)
% input banded matrix and rhs vector
%
iprint = 0
N = 8; NBW = 5; A = zeros(N,NBW);
A = ...
    [10 0 6 0  0;
      3 1 0 2  0;
      9 0 0 0  0;
      7 0 0 0 -5;
      4 0 0 0  0;
      6 0 0 0  0;
      1 0 0 0  0;
      8 0 0 0  0];
B = ...
 [1 8 3 4 -5 7 -6 2]';  % column vector
%
% LU decomposition: L occupies strict lower triangle in [A] with L(i,i)=1 implicit
for K = 1:N-1
  NBK = min(N-K+1,NBW);
  PR = A(K,1:NBK); % store pivot row temporarily
  for I = K+1:NBK+K-1
    I1 = I-K+1;
    C = PR(I1)/PR(1); A(K,I1) = C;
    for J = I:NBK+K-1
      J1 = J-I+1; J2 = J-K+1;  
      A(I,J1) = A(I,J1) - C*PR(J2);
    end
  end
end
% forward reduction: L y = b -- note: L(i,i) = 1
for I = 2:N
  NBK = max(1,I-NBW+1);
  for K = NBK:I-1
     B(I) = B(I) - A(K,I-K+1)*B(K);
  end
end
% back substitution: U x = y
B(N) = B(N)/A(N,1);
for I=2:N
  irow = N-I+1;
  sum = 0;
  NBK = min(NBW+irow-1,N);
  for J=irow+1:NBK
    sum = sum + A(irow,1)*A(irow,J-irow+1)*B(J);
  end
  B(irow) = (B(irow)-sum)/A(irow,1);
end
%
disp(' ')
disp('Solution Vector');
disp(sprintf('%12.4E\n',B'));
%
if iprint == 1
  L = eye(N);
  for I = 2:N
    NBK = max(1,I-NBW+1);
    for K = NBK:I-1
      L(I,K) = A(K,I-K+1);
    end
  end
  D1 = A(:,1);
  D = diag(D1);
  U = D*L';
  L,U
end
