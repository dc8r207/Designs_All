# import CELERY
from .celery import app as celery_app
