# Simple Django Blog by John Elder from Codemy.com

https://www.youtube.com/playlist?list=PLCC34OHNcOtr025c1kHSPrnP18YPB-NFi
