# Notes for the user flow

Product list

|

Product detail (add the item to cart)

|

Cart view (order detail view) (all the items in our cart)

|

Checkout (addresses)

|

Payment

|

Order confirmation
