cliffs-src
==========

Source code for a numerical model (Cliffs) to simulate tsunami propagation and run-up on land.

Cliffs User Manual at <http://arxiv.org/abs/1410.0753>

Cliffs' home page at <http://elena.tolkov.com/Cliffs.htm>


